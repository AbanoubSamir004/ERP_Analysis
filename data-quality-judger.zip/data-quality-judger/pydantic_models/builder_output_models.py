"""
Builder Output Pydantic Models

These models represent the output of the GX Context Builder (Task 1).

The builder output is passed to:
- Task 2 (Runner): Uses checkpoint_metadata to know which checkpoints to run
- Airflow: The output will be XCom'd between DAG tasks

Note: Some fields contain GX objects (FileDataContext, Checkpoint) which
are not JSON-serializable. For XCom, only the serializable metadata is passed.

Author: DGQ Team
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from pydantic_models.ui_config_models import PolarisPath


class CheckpointBuildMetacontent(BaseModel):
    """
    Build-time metacontent for a single checkpoint created by the builder.
    
    This is passed to Task 2 (Runner) to know:
    - Which checkpoint to run
    - Which table's data to load
    - What dimensions were configured (for logging/debugging)
    
    One CheckpointBuildMetacontent per table in the Use Case.
    """
    
    checkpoint_name: str = Field(
        ...,
        description="Name of the checkpoint (e.g., 'CUSTOMERS---checkpoint')",
    )
    table_id: int = Field(
        ...,
        description="Table ID from the UI config (table_id)",
    )
    table_name: str = Field(
        ...,
        description="Table name used as the GX asset name",
    )
    polaris_path: PolarisPath = Field(
        ...,
        description="Polaris path to load the table's data",
    )
    batch_def_name: str = Field(
        ...,
        description="Name of the batch definition (e.g., 'CUSTOMERS---whole_batch')",
    )
    dq_dimensions: list[str] = Field(
        ...,
        description="List of DQ dimensions covered by this checkpoint's validations",
    )
    validation_def_count: int = Field(
        ...,
        ge=0,
        description="Number of validation definitions (one per dimension)",
    )


class BuilderOutput(BaseModel):
    """
    Complete output of build_gx_artifacts_from_config().
    
    This is returned by Task 1 and contains:
    - GX objects (context, checkpoints) for immediate use
    - Serializable metadata for passing to Task 2 via Airflow XCom
    
    Note: The 'context' and 'checkpoints' fields contain GX objects
    which are not JSON-serializable. For XCom, use to_xcom_dict().
    """
    
    context: Any = Field(
        ...,
        description="GX FileDataContext object (not serializable)",
    )
    checkpoints: list[Any] = Field(
        ...,
        description="List of GX Checkpoint objects (not serializable)",
    )
    checkpoints_build_metacontent: list[CheckpointBuildMetacontent] = Field(
        ...,
        description="Serializable build-time metacontent for each checkpoint (for Task 2)",
    )
    context_root_dir: str = Field(
        ...,
        description="Path to the GX context root directory",
    )
    
    model_config = ConfigDict(arbitrary_types_allowed=True)  # Allow GX objects
    
    def to_xcom_dict(self) -> dict:
        """
        Convert to a dict suitable for Airflow XCom.
        
        Excludes non-serializable GX objects and converts
        checkpoints_build_metacontent to plain dicts.
        
        Returns:
            Dict with context_root_dir and checkpoints_build_metacontent (as dicts).
        """
        return {
            "context_root_dir": self.context_root_dir,
            "checkpoints_build_metacontent": [cm.model_dump() for cm in self.checkpoints_build_metacontent],
        }
    
    def get_checkpoint_names(self) -> list[str]:
        """Get list of checkpoint names for logging."""
        return [cm.checkpoint_name for cm in self.checkpoints_build_metacontent]
