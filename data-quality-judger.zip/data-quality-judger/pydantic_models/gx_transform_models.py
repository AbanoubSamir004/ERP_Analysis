"""
GX Transform Pydantic Models

These models represent the intermediate data structures used when
transforming UI rules to GX-compatible format.

The transformation flow:
    UIRule (UI format)
        -> transform_ui_rule_to_gx_format()
        -> TransformedGXRule (GX format)
        -> group_rules_by_dq_dimension()
        -> GroupedRulesByDimension (grouped for Suite creation)

Key differences between UI and GX formats:
- UI: meta fields (description, dq_dimension) are sibling keys to 'parameters'
- GX: meta fields are nested inside params['meta']
- GX: column name is injected into params for column-level expectations

Author: DGQ Team
"""

from typing import Any

from pydantic import BaseModel, Field

from pydantic_models.ui_config_models import PolarisPath


# -----------------------------------------------------------------------------
# Context Models (passed to transform functions)
# -----------------------------------------------------------------------------


class TableMetacontent(BaseModel):
    """
    Table-level metacontent passed to transform functions.
    
    This is extracted from UITableConfig and passed to transform_ui_rule_to_gx_format()
    so that each rule knows which table it belongs to. This metacontent is then
    embedded into the rule's meta dict for Task 3 to use.
    
    Note: This is a subset of UITableConfig, containing only the fields
    needed for the meta dict.
    """
    
    table_id: int = Field(
        ...,
        description="Internal table ID from UITableConfig",
    )
    polaris_path: PolarisPath = Field(
        ...,
        description="Polaris path to locate the table's data",
    )


class UseCaseMetacontent(BaseModel):
    """
    Use Case-level metacontent passed to transform functions.
    
    This is extracted from UIUseCaseConfig and passed through the transform
    chain so that each rule's meta dict includes the full metacontent needed
    by Task 3 to identify where results should be stored.
    
    Note: This is a subset of UIUseCaseConfig, containing only the fields
    needed for the meta dict.
    """
    
    use_case_name: str = Field(
        ...,
        description="Name of the Use Case this rule belongs to",
    )
    domain: str = Field(
        ...,
        description="Domain responsible for this Use Case",
    )
    version: int = Field(
        ...,
        description="Version number of the Use Case config",
    )


# -----------------------------------------------------------------------------
# Transformed Rule Models (output of transform functions)
# -----------------------------------------------------------------------------


class RuleMeta(BaseModel):
    """
    Metadata embedded in each GX expectation's meta dict.
    
    This contains all the context needed by Task 3 to:
    - Identify which rule this result belongs to
    - Know the table and use case context
    - Reconstruct the original parameters for reporting
    
    The meta dict is preserved through GX validation and appears
    in the checkpoint result JSON.
    """
    
    # Rule-level identifiers
    rule_id: int = Field(
        ...,
        description="Internal rule ID from the UI config",
    )
    dq_dimension: str = Field(
        ...,
        description="DQ dimension (e.g., 'completeness', 'uniqueness')",
    )
    description: str | None = Field(
        default=None,
        description="Human-readable description from the UI",
    )
    
    # Table-level context
    table_id: int = Field(
        ...,
        description="Internal table ID this rule belongs to",
    )
    table_name: str = Field(
        ...,
        description="Table name from polaris_path.table",
    )
    polaris_path: PolarisPath = Field(
        ...,
        description="Full Polaris path for data location",
    )
    
    # Use Case-level context
    use_case_name: str = Field(
        ...,
        description="Name of the parent Use Case",
    )
    domain: str = Field(
        ...,
        description="Domain of the Use Case",
    )
    version: int = Field(
        ...,
        description="Version of the Use Case config",
    )
    
    # Original parameters (for reporting)
    original_parameters: dict[str, Any] = Field(
        ...,
        description="Copy of the original UI parameters for Task 3 reporting",
    )


class GXRuleParams(BaseModel, extra="allow"):
    """
    Parameters for a GX expectation.
    
    This is the 'params' field in TransformedGXRule. It contains:
    - Known GX expectation kwargs (column, meta, etc.)
    - Unknown expectation-specific kwargs via extra='allow' (e.g., value_set, min_value)
    - A 'meta' sub-dict with RuleMeta for traceability
    
    When unpacking into a GX expectation constructor, all fields (known + extra)
    are passed as kwargs: expectation_class(**params.model_dump())
    
    The unknown params come from **rule.parameters in the UI config and can include:
    - value_set, min_value, max_value, mostly, regex, strftime_format, etc.
    """
    
    meta: RuleMeta = Field(
        ...,
        description="Metadata for traceability and Task 3 reporting",
    )
    column: str | None = Field(
        default=None,
        description="Column name (injected for column-level expectations, None for table-level)",
    )
    # All other GX expectation params (mostly, value_set, min_value, etc.)
    # are accepted via extra='allow' and come from **rule.parameters


class TransformedGXRule(BaseModel):
    """
    A single rule in GX-compatible format.
    
    This is the output of transform_ui_rule_to_gx_format() and represents
    a single GX expectation ready to be added to an ExpectationSuite.
    
    The 'params' dict can be unpacked directly into the GX expectation constructor:
        expectation_class = getattr(gx.expectations, rule.expectation_type)
        expectation = expectation_class(**rule.params)
    """
    
    expectation_type: str = Field(
        ...,
        description="GX expectation class name (e.g., 'ExpectColumnValuesToNotBeNull')",
    )
    dq_dimension: str = Field(
        ...,
        description="DQ dimension for grouping into Suites (e.g., 'completeness')",
    )
    params: GXRuleParams = Field(
        ...,
        description="GX expectation kwargs including 'meta' sub-dict. Unpack with **params.model_dump().",
    )


# -----------------------------------------------------------------------------
# Grouped Rules Model (output of group_rules_by_dq_dimension)
# -----------------------------------------------------------------------------


class GroupedRulesByDimension(BaseModel):
    """
    Rules grouped by their DQ dimension.
    
    This is the output of group_rules_by_dq_dimension() and is used
    to create one ExpectationSuite per dimension, resulting in cleaner
    Data Docs that show results organized by dimension.
    
    Example:
        {
            "completeness": [TransformedGXRule, ...],
            "uniqueness": [TransformedGXRule, ...],
            "validity": [TransformedGXRule, ...]
        }
    """
    
    # Using __root__ pattern for dict-like model
    # In Pydantic v2, this would be model_validator or RootModel
    rules_by_dimension: dict[str, list[TransformedGXRule]] = Field(
        ...,
        description="Dict mapping DQ dimension name to list of rules for that dimension",
    )
    
    def get_dimensions(self) -> list[str]:
        """Get list of dimension names."""
        return list(self.rules_by_dimension.keys())
    
    def get_rules(self, dimension: str) -> list[TransformedGXRule]:
        """Get rules for a specific dimension."""
        return self.rules_by_dimension.get(dimension, [])
    
    def __iter__(self):
        """Allow iteration over (dimension, rules) pairs."""
        return iter(self.rules_by_dimension.items())
