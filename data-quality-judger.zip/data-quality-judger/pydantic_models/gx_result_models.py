"""
GX Checkpoint Result Pydantic Models

These models represent the structure of GX checkpoint validation results.
The checkpoint result comes from checkpoint.run().describe() and contains
detailed information about each validation's success/failure.

This is used in Task 2 (Runner) to parse and serialize checkpoint results
before uploading to blob storage.

Structure:
    GXCheckpointResult (top-level checkpoint result)
    |-- statistics: GXCheckpointStatistics
    |-- validation_results: list[GXExpectationSuiteValidationResult]
    |   +-- results: list[GXExpectationValidationResult]
    |       |-- expectation_config: ExpectationConfig (type, kwargs, meta)
    |       +-- result: dict (validation outcome, using extra='allow')
    +-- checkpoint_run_metacontent: CheckpointRunMetacontent (our custom metadata added by Task 2)

Author: DGQ Team
"""

from typing import Any

from pydantic import BaseModel, Field

from pydantic_models.ui_config_models import UITableConfig


# -----------------------------------------------------------------------------
# Nested Models (from inner to outer)
# -----------------------------------------------------------------------------


class ExpectationConfig(BaseModel, extra="allow"):
    """
    Configuration of an expectation as stored by GX.
    
    This is nested inside each expectation validation result and contains
    the expectation type, parameters (kwargs), and metadata.
    
    Note on expectation type naming:
        GX internally uses snake_case for expectation types (e.g., 'expect_column_values_to_not_be_null').
        However, our system currently uses PascalCase class names (e.g., 'ExpectColumnValuesToNotBeNull')
        for compatibility with the UI and existing code.
        
        TODO (later sprint): Refactor the entire codebase to use snake_case for expectation types
        to align with GX's internal representation. This includes:
        - Creating snake_to_pascal() and pascal_to_snake() functions in gx_helpers.py
        - Updating use_case_config.json to store snake_case expectation types
        - Updating UI to display PascalCase but store snake_case in JSON
        See xx_judger_next_steps_tmp.md for full refactoring plan.
    """
    
    type: str = Field(
        ...,
        description=(
            "GX expectation class name in PascalCase (e.g., 'ExpectColumnValuesToNotBeNull'). "
            "Note: GX internally uses snake_case, but we use PascalCase for UI compatibility."
        ),
    )
    kwargs: dict[str, Any] = Field(
        ...,
        description="Expectation kwargs (column, min_value, value_set, severity, etc.)",
    )
    meta: dict[str, Any] = Field(
        default_factory=dict,
        description="Expectation metadata (rule_id, dq_dimension, description, table_id, polaris_path, etc.)",
    )
    # GX may add other fields
    # Captured via extra='allow'


class GXExpectationValidationResult(BaseModel, extra="allow"):
    """
    Result of a single expectation validation.
    
    This appears in the 'results' array within each validation_result.
    The 'result' field varies by expectation type, so we use extra='allow'
    to capture all possible fields.
    
    Example (from GX checkpoint.run().describe() output):
        {
            "success": false,
            "expectation_config": {
                "type": "ExpectColumnValuesToBeInSet",
                "kwargs": {"column": "status", "value_set": ["Active", "Inactive"]},
                "meta": {"rule_id": "4---ExpectColumnValuesToBeInSet", "dq_dimension": "validity", ...}
            },
            "result": {
                "element_count": 10000,
                "unexpected_count": 45,
                "unexpected_percent": 0.45,
                "partial_unexpected_list": ["unknown", "deleted", ...],
                ...
            }
        }
    """
    
    success: bool = Field(
        ...,
        description="Whether this expectation passed",
    )
    expectation_config: ExpectationConfig = Field(
        ...,
        description="Expectation configuration with type, kwargs, and meta",
    )
    result: dict[str, Any] = Field(
        ...,
        description="Validation result details (observed_value, unexpected_count, etc.)",
    )
    # GX may add other fields like 'exception_info', etc.
    # Captured via extra='allow'


class GXValidationStatistics(BaseModel):
    """
    Statistics for a single validation result (one suite run).
    
    Summarizes how many expectations were evaluated and passed/failed.
    """
    
    evaluated_expectations: int = Field(
        ...,
        description="Total number of expectations evaluated in this suite",
    )
    successful_expectations: int = Field(
        ...,
        description="Number of expectations that passed",
    )
    unsuccessful_expectations: int = Field(
        ...,
        description="Number of expectations that failed",
    )
    success_percent: float = Field(
        ...,
        description="Percentage of expectations that passed (0.0-100.0)",
    )


class GXExpectationSuiteValidationResult(BaseModel, extra="allow"):
    """
    Result of validating one expectation suite against a batch.
    
    This appears in the 'validation_results' array of the checkpoint result.
    Each validation_result corresponds to running one suite on one batch.
    
    Uses extra='allow' because GX may include additional fields like
    'result_url', 'batch_definition', 'batch_spec', etc.
    """
    
    success: bool = Field(
        ...,
        description="Whether all expectations in this suite passed",
    )
    statistics: GXValidationStatistics = Field(
        ...,
        description="High-level statistics for this validation",
    )
    results: list[GXExpectationValidationResult] = Field(
        ...,
        description="Detailed results for each expectation in the suite",
    )
    result_url: str | None = Field(
        default=None,
        description="URL to the validation result in Data Docs (if generated)",
    )
    # GX includes many other fields: batch_definition, batch_spec, etc.
    # Captured via extra='allow'


class GXCheckpointStatistics(BaseModel):
    """
    Top-level statistics for the entire checkpoint run.
    
    Summarizes how many validation results (suite runs) were evaluated.
    """
    
    evaluated_validations: int = Field(
        ...,
        description="Total number of validation results (suite runs) in this checkpoint",
    )
    success_percent: float = Field(
        ...,
        description="Percentage of validation results that passed (0.0-100.0)",
    )
    successful_validations: int = Field(
        ...,
        description="Number of validation results where all expectations passed",
    )
    unsuccessful_validations: int = Field(
        ...,
        description="Number of validation results with at least one failed expectation",
    )


class CheckpointRunMetacontent(BaseModel):
    """
    Custom metadata added by Task 2 to track checkpoint execution.
    
    This is injected into the checkpoint result before uploading to blob storage.
    It provides context for Task 3 (Judger) to identify the run and locate the data.
    """
    
    run_id: str = Field(
        ...,
        description="Unique identifier for this run (timestamp---checkpoint_name)",
    )
    run_timestamp: str = Field(
        ...,
        description="ISO timestamp when the checkpoint was executed",
    )
    checkpoint_name: str = Field(
        ...,
        description="Name of the checkpoint",
    )
    table_config: UITableConfig = Field(
        ...,
        description="Full table configuration including table_id, table_name, polaris_path, and rules",
    )


# -----------------------------------------------------------------------------
# Top-Level Checkpoint Result Model
# -----------------------------------------------------------------------------


class GXCheckpointResult(BaseModel, extra="allow"):
    """
    Complete result of a GX checkpoint run.
    
    This is the parsed output of checkpoint.run().describe() with our custom
    checkpoint_run_metacontent added. It contains:
    - Overall success status
    - Top-level statistics
    - Detailed validation results for each suite
    - Our custom run metadata (run_id, timestamp, polaris_path, etc.)
    
    Uses extra='allow' because GX may include additional checkpoint-level fields
    like 'checkpoint_config', 'run_time', etc.
    
    This model is used to:
    1. Parse the checkpoint result after execution
    2. Serialize for upload to blob storage
    3. Validate structure before passing to Task 3
    """
    
    success: bool = Field(
        ...,
        description="Whether all validations in all suites passed",
    )
    statistics: GXCheckpointStatistics = Field(
        ...,
        description="High-level statistics for the checkpoint",
    )
    validation_results: list[GXExpectationSuiteValidationResult] = Field(
        ...,
        description="Detailed validation results for each suite run",
    )
    checkpoint_run_metacontent: CheckpointRunMetacontent = Field(
        ...,
        description="Custom metadata added by Task 2 for traceability",
    )
    # GX may include other fields like 'checkpoint_config', 'run_time', etc.
    # Captured via extra='allow'


# -----------------------------------------------------------------------------
# Use Case Summary Result Model (for entire Use Case execution)
# -----------------------------------------------------------------------------


class FailedExpectationDetail(BaseModel):
    """
    Details of a single failed expectation for notification purposes.
    
    This is used to provide actionable failure information in email/Jira notifications
    without requiring users to dive into Data Docs for every failure.
    """
    
    rule_id: int = Field(
        ...,
        description=(
            "Internal rule ID from the Use Case configuration (rule_id in use_case_config.json). "
            "This is the integer ID assigned by the UI, not a composite string."
        ),
    )
    expectation_name: str = Field(
        ...,
        description=(
            "Expectation class name in PascalCase (e.g., 'ExpectColumnValuesToNotBeNull'). "
            "See ExpectationConfig.type for naming convention notes."
        ),
    )
    expectation_description: str = Field(
        ...,
        description=(
            "Human-readable description of the expectation, e.g., "
            "'`status` values must belong to this set: `active` `inactive` `pending`, at least 95% of the time.'"
        ),
    )
    column: str | None = Field(
        default=None,
        description="Target column name (None for table-level expectations)",
    )
    unexpected_count: int | None = Field(
        default=None,
        description="Number of unexpected (failing) values",
    )
    unexpected_percent: float | None = Field(
        default=None,
        description="Percentage of unexpected values (0.0-100.0)",
    )
    sample_unexpected_values: list[Any] | None = Field(
        default=None,
        description="Sample of unexpected values from partial_unexpected_list (first N items, configurable)",
    )
    # TODO (optional, later sprint): Add failure_description field
    # This would be a human-readable summary of why the expectation failed,
    # e.g., "Column 'email' has 15 null values (3.2%)".
    # GX does not natively output this, so we would need to construct it ourselves
    # based on the expectation type and result values.
    # failure_description: str | None = Field(
    #     default=None,
    #     description="Human-readable summary of the failure reason",
    # )


class TableValidationSummary(BaseModel):
    """
    Summary of validation results for a single table.
    
    Each table has one checkpoint, and this captures the key metrics.
    """
    
    table_id: int = Field(
        ...,
        description="Internal table ID from the Use Case configuration",
    )
    displayed_table_name: str = Field(
        ...,
        description="Display name of the table (with namespace if needed for disambiguation)",
    )
    catalog: str = Field(
        ...,
        description="Polaris catalog name",
    )
    namespace: str = Field(
        ...,
        description="Polaris namespace (e.g., isu_vertrieb.sales_schema)",
    )
    table: str = Field(
        ...,
        description="Polaris table name",
    )
    success: bool = Field(
        ...,
        description="Whether all validations passed for this table",
    )
    total_expectations: int = Field(
        ...,
        ge=0,
        description="Total number of expectations evaluated",
    )
    passed_expectations: int = Field(
        ...,
        ge=0,
        description="Number of expectations that passed",
    )
    failed_expectations: int = Field(
        ...,
        ge=0,
        description="Number of expectations that failed",
    )
    success_percent: float = Field(
        ...,
        ge=0.0,
        le=100.0,
        description="Percentage of expectations that passed",
    )
    error_message: str | None = Field(
        default=None,
        description="Error message if execution failed (None if successful)",
    )
    checkpoint_run_id: str = Field(
        ...,
        description="Unique run identifier for this table's checkpoint (from CheckpointRunMetacontent.run_id)",
    )
    failed_expectation_details: list[FailedExpectationDetail] = Field(
        default_factory=list,
        description="Details of each failed expectation for notification purposes",
    )


class UseCaseSummaryResult(BaseModel):
    """
    Summary of an entire Use Case execution (all table validations).
    
    This aggregates results from all table checkpoint runs within a Use Case
    and is used for high-level reporting and notifications at the Use Case level.
    
    Uses table-focused terminology instead of checkpoint terminology for
    business-friendly reporting.
    
    Used for:
    - Return value from process_checkpoint_results() in Task 3
    - Email notifications to stakeholders
    - Persisting summary to Polaris DQ summary table
    """
    
    domain: str = Field(
        ...,
        description="Domain identifier (e.g., 'enercity_ag')",
    )
    use_case_name: str = Field(
        ...,
        description="Name of the Use Case",
    )
    # TODO: use_case_version can be fetched from the UI config JSON file
    # (use_case_config.json) which contains a "version" field. In Task 3,
    # we would need to either:
    # 1. Download and parse the use_case_config.json from blob storage, or
    # 2. Include version in CheckpointBuildMetacontent passed from Task 1
    # For now, this is skipped until we implement the config loading in Task 3.
    # use_case_version: str = Field(
    #     ...,
    #     description="Version of the Use Case configuration",
    # )
    total_tables: int = Field(
        ...,
        ge=0,
        description="Total number of tables validated",
    )
    passed_tables: int = Field(
        ...,
        ge=0,
        description="Number of tables where all validations passed",
    )
    failed_tables: int = Field(
        ...,
        ge=0,
        description="Number of tables with validation failures (includes execution errors)",
    )
    table_results: list[TableValidationSummary] = Field(
        ...,
        description="Individual table validation summaries",
    )
    # TODO (later sprint): Move all blob paths to env_config.py as full path constants
    # e.g., GX_OUTPUT_DATA_DOCS_PATH = "gx_output/data_docs/local_site"
    # This would centralize path definitions and make them configurable.
    data_docs_path: str = Field(
        ...,
        description="Blob path where Data Docs were uploaded",
    )
    run_timestamp: str = Field(
        ...,
        description="ISO timestamp when Task 3 completed aggregation",
    )
    
    @property
    def overall_success(self) -> bool:
        """
        Whether the entire Use Case execution was successful.
        
        Returns True only if all tables passed (no failures).
        """
        return self.failed_tables == 0
    
    def to_log_string(self) -> str:
        """
        Format the Use Case summary as a human-readable string for logging.
        
        Returns:
            Multi-line formatted string with Use Case execution details.
        """
        lines = [
            "=" * 60,
            "USE CASE EXECUTION SUMMARY",
            "=" * 60,
            f"Use Case: {self.domain}/{self.use_case_name}",
            f"Run Timestamp: {self.run_timestamp}",
            f"Total Tables: {self.total_tables}",
            f"Passed: {self.passed_tables}",
            f"Failed: {self.failed_tables}",
            f"Overall Status: {'PASS' if self.overall_success else 'FAIL'}",
            f"Data Docs: {self.data_docs_path}",
            "=" * 60,
            "",
            "Table Results:",
        ]
        
        for table_result in self.table_results:
            status = "PASS" if table_result.success else ("ERROR" if table_result.error_message else "FAIL")
            lines.append(
                f"  - {table_result.displayed_table_name} ({table_result.namespace}.{table_result.table}): {status} "
                f"({table_result.passed_expectations}/{table_result.total_expectations} passed, "
                f"{table_result.success_percent:.1f}%)"
            )
            if table_result.error_message:
                lines.append(f"    Error: {table_result.error_message}")
            # Show failed expectation details if any
            for failed_exp in table_result.failed_expectation_details:
                col_info = f" (column: {failed_exp.column})" if failed_exp.column else ""
                count_info = f" - {failed_exp.unexpected_count} unexpected" if failed_exp.unexpected_count else ""
                lines.append(f"      - {failed_exp.expectation_name}{col_info}{count_info}")
        
        lines.append("=" * 60)
        
        return "\n".join(lines)


