"""
UI Configuration Pydantic Models

These models represent the JSON configuration structure that comes from the Streamlit UI.
The UI allows users to define DQ rules for tables, and this configuration is stored
in blob storage and used by the GX Context Builder (Task 1) to create GX artifacts.

Hierarchy:
    UIUseCaseConfig (top-level)
    |-- tables: list[UITableConfig]
    |   |-- polaris_path: PolarisPath
    |   |-- table_rules: list[UIRule]
    |   +-- column_rules: list[ColumnRuleGroup]
    |       +-- rules: list[UIRule]
    |-- multi_source_rules: list[MultiSourceRule]
    +-- actions: list[ActionConfig]

Author: DGQ Team
"""

from typing import Any, Literal

from pydantic import BaseModel, Field


# -----------------------------------------------------------------------------
# Shared / Nested Models
# -----------------------------------------------------------------------------


class PolarisPath(BaseModel):
    """
    Polaris Catalog path identifying a table in the data lake.
    
    This is used to locate the actual data when running validations.
    The path follows the Iceberg catalog structure: catalog.namespace.table
    """
    
    catalog: str = Field(
        ...,
        description="Polaris catalog name (e.g., 'enercity_catalog')",
    )
    namespace: str = Field(
        ...,
        description="Dot-separated namespace path (e.g., 'encore_team.isu_vertrieb.sales_schema')",
    )
    table: str = Field(
        ...,
        description="Table name (e.g., 'CUSTOMERS'). Used as the GX asset name.",
    )


class RuleParameters(BaseModel, extra="allow"):
    """
    GX expectation parameters configured by the user.
    
    This model uses extra="allow" to accept any GX expectation kwargs.
    Common fields are defined explicitly, but any additional kwargs
    specific to the expectation type will be passed through.
    
    Note: 'severity' is stored here (not in meta) because it's used
    by the validation logic, not just for documentation.
    """
    
    severity: Literal["critical", "warning", "info"] = Field(
        default="warning",
        description="Severity level for this rule. 'critical' failures block pipelines.",
    )
    mostly: float | None = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Fraction of values that must pass (0.0-1.0). None means 100%.",
    )
    # Additional kwargs are allowed via extra="allow"


class UIRule(BaseModel):
    """
    A single DQ rule as defined in the UI.
    
    This represents one expectation that will be applied to a table or column.
    The UI stores meta fields (description, dq_dimension) as sibling keys to
    'parameters', which is different from how GX expects them (inside meta).
    
    The transform functions convert this UI format to GX format.
    """
    
    rule_id: int = Field(
        ...,
        description="Internal rule ID within this Use Case config. Auto-incremented by UI.",
    )
    expectation_type: str = Field(
        ...,
        description="GX expectation class name (e.g., 'ExpectColumnValuesToNotBeNull')",
    )
    dq_dimension: str = Field(
        ...,
        description="Data quality dimension (e.g., 'completeness', 'uniqueness', 'validity')",
    )
    description: str | None = Field(
        default=None,
        description="Human-readable description of what this rule checks",
    )
    parameters: dict[str, Any] = Field(
        default_factory=dict,
        description="GX expectation kwargs including severity, mostly, value_set, etc.",
    )


class ColumnRuleGroup(BaseModel):
    """
    A group of rules applied to one or more columns.
    
    The UI allows users to select multiple columns and apply the same
    set of rules to all of them. This reduces repetition in the config.
    
    Example: Apply NotNull and Unique checks to both 'customer_id' and 'order_id'.
    """
    
    columns: list[str] = Field(
        ...,
        min_length=1,
        description="List of column names these rules apply to",
    )
    rules: list[UIRule] = Field(
        ...,
        description="List of rules to apply to each column in 'columns'",
    )


# -----------------------------------------------------------------------------
# Table Configuration
# -----------------------------------------------------------------------------


class UITableConfig(BaseModel):
    """
    Configuration for a single table within a Use Case.
    
    Contains all the DQ rules (both table-level and column-level) that
    should be applied to this table. Used as input to transform functions
    that convert UI rules to GX expectations.
    
    This is a sub-component of UIUseCaseConfig.tables
    """
    
    table_id: int = Field(
        ...,
        description="Internal table ID within this Use Case. Auto-incremented by UI.",
    )
    table_name: str = Field(
        ...,
        description=(
            "Display name for the table (handles namespace disambiguation). "
            "Same as polaris_path.table if unique, or includes namespace prefix if duplicates exist."
        ),
    )
    polaris_path: PolarisPath = Field(
        ...,
        description="Polaris catalog path to locate this table's data",
    )
    table_rules: list[UIRule] = Field(
        default_factory=list,
        description="Table-level rules (e.g., row count, column set). No 'column' param.",
    )
    column_rules: list[ColumnRuleGroup] = Field(
        default_factory=list,
        description="Column-level rules grouped by target columns",
    )


# -----------------------------------------------------------------------------
# Multi-Source Rules
# -----------------------------------------------------------------------------


class MultiSourceRule(BaseModel):
    """
    A rule that validates relationships across multiple tables.
    
    These rules use SQL queries to check cross-table consistency,
    such as referential integrity between ORDERS and CUSTOMERS.
    
    Note: Not yet fully implemented in Task 2.
    """
    
    rule_id: int = Field(
        ...,
        description="Internal rule ID within this Use Case config",
    )
    combination_name: str = Field(
        ...,
        description="Human-readable name for this table combination (e.g., 'CUSTOMERS-ORDERS')",
    )
    expectation_type: str = Field(
        ...,
        description="GX expectation type (typically 'UnexpectedRowsExpectation' for SQL)",
    )
    table_ids: list[int] = Field(
        ...,
        description="List of table IDs involved in this rule",
    )
    table_names: list[str] = Field(
        ...,
        description="List of table names involved (for readability)",
    )
    dq_dimension: str = Field(
        ...,
        description="DQ dimension (typically 'consistency' for cross-table rules)",
    )
    description: str | None = Field(
        default=None,
        description="Human-readable description of what this rule checks",
    )
    parameters: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters including 'unexpected_rows_query' SQL and severity",
    )


# -----------------------------------------------------------------------------
# Actions (Notifications)
# -----------------------------------------------------------------------------


class ActionConfig(BaseModel):
    """
    Configuration for an action to take based on validation results.
    
    Actions are triggered after checkpoint execution, such as sending
    emails or creating Jira tickets when validations fail.
    
    Note: Actions are defined in config but not yet implemented in code.
    """
    
    type: Literal["email", "jira_ticket", "teams_notification"] = Field(
        ...,
        description="Type of action to perform",
    )
    enabled: bool = Field(
        default=True,
        description="Whether this action is currently active",
    )
    config: dict[str, Any] = Field(
        default_factory=dict,
        description="Action-specific configuration (e.g., email addresses, Jira project)",
    )


# -----------------------------------------------------------------------------
# Top-Level Use Case Configuration
# -----------------------------------------------------------------------------


class UIUseCaseConfig(BaseModel):
    """
    Top-level configuration for a DQ Use Case.
    
    This is the complete JSON structure that comes from the Streamlit UI
    and is stored in blob storage. It contains all tables, rules, and
    actions for a single Use Case.
    
    This is the main input to build_gx_artifacts_from_config().
    
    Example path: {owner}/{use_case_name}/user_input/use_case_config.json
    """
    
    use_case_name: str = Field(
        ...,
        description="Unique name for this Use Case (e.g., 'finance_gl_checks')",
    )
    version: int = Field(
        ...,
        ge=1,
        description="Configuration version number. Incremented on each save.",
    )
    description: str | None = Field(
        default=None,
        description="Human-readable description of this Use Case's purpose",
    )
    domain: str = Field(
        ...,
        description="Domain that owns this Use Case (e.g., 'enercity_ag', 'enercity_netz', 'enercity_cross')",
    )
    schedule: str | None = Field(
        default=None,
        description="Cron expression for scheduled execution (e.g., '0 0 * * *' for daily)",
    )
    created_at: str | None = Field(
        default=None,
        description="ISO timestamp when this config was first created",
    )
    updated_at: str | None = Field(
        default=None,
        description="ISO timestamp when this config was last modified",
    )
    
    # Internal tracking fields (used by UI, not by GX)
    next_table_id: int = Field(
        default=1,
        description="Next auto-increment value for table_id",
    )
    next_rule_id: int = Field(
        default=1,
        description="Next auto-increment value for rule_id",
    )
    
    # Core content
    tables: list[UITableConfig] = Field(
        default_factory=list,
        description="List of tables with their DQ rules",
    )
    multi_source_rules: list[MultiSourceRule] = Field(
        default_factory=list,
        description="Cross-table validation rules",
    )
    actions: list[ActionConfig] = Field(
        default_factory=list,
        description="Actions to trigger on validation results",
    )
