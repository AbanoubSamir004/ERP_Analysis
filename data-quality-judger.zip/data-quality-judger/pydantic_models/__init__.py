"""
Pydantic Models for DQ Judger

This package contains Pydantic models for validating and documenting
the data structures used throughout the DQ Judger system.

Models are organized into:
- ui_config_models: Models for the UI JSON configuration (input from Streamlit UI)
- gx_transform_models: Models for GX rule transformation (internal processing)
- builder_output_models: Models for GX context builder outputs (Task 1 results)
"""

from pydantic_models.ui_config_models import (
    PolarisPath,
    RuleParameters,
    UIRule,
    ColumnRuleGroup,
    UITableConfig,
    MultiSourceRule,
    ActionConfig,
    UIUseCaseConfig,
)

from pydantic_models.gx_transform_models import (
    TableMetacontent,
    UseCaseMetacontent,
    RuleMeta,
    GXRuleParams,
    TransformedGXRule,
    GroupedRulesByDimension,
)

from pydantic_models.builder_output_models import (
    CheckpointBuildMetacontent,
    BuilderOutput,
)

from pydantic_models.gx_result_models import (
    ExpectationConfig,
    GXExpectationValidationResult,
    GXValidationStatistics,
    GXExpectationSuiteValidationResult,
    GXCheckpointStatistics,
    CheckpointRunMetacontent,
    GXCheckpointResult,
    FailedExpectationDetail,
    TableValidationSummary,
    UseCaseSummaryResult,
)

__all__ = [
    # UI Config Models
    "PolarisPath",
    "RuleParameters",
    "UIRule",
    "ColumnRuleGroup",
    "UITableConfig",
    "MultiSourceRule",
    "ActionConfig",
    "UIUseCaseConfig",
    # GX Transform Models
    "TableMetacontent",
    "UseCaseMetacontent",
    "RuleMeta",
    "GXRuleParams",
    "TransformedGXRule",
    "GroupedRulesByDimension",
    # Builder Output Models
    "CheckpointBuildMetacontent",
    "BuilderOutput",
    # GX Result Models
    "ExpectationConfig",
    "GXExpectationValidationResult",
    "GXValidationStatistics",
    "GXExpectationSuiteValidationResult",
    "GXCheckpointStatistics",
    "CheckpointRunMetacontent",
    "GXCheckpointResult",
    "FailedExpectationDetail",
    "TableValidationSummary",
    "UseCaseSummaryResult",
]
