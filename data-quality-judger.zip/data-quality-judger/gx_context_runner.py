"""
GX Context Runner Module

Executes GX checkpoints against DataFrames loaded from catalog.
This is the core of DAG Task 2.

Workflow:
1. Download GX context from blob storage
2. Load DataFrame(s) from catalog (Polaris or mock)
3. Run checkpoint with batch_parameters
4. Upload result JSON and Data Docs to blob storage
5. Return result paths for Task 3

Execution mode:
- CLI: Execute all checkpoints for a Use Case in sequence
- Returns success status and result paths for each checkpoint

Error Handling:
- Validation failures (expected behavior): Logged, returned as success=False in result
- Execution errors (Spark issues, etc.): Caught, logged, returned in error field

"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import great_expectations as gx

from blob_utils import (
    download_gx_context,
    upload_checkpoint_result,
    upload_data_docs,
)
from custom_logger import logger
from env_config import settings
from pydantic_models import (
    CheckpointBuildMetacontent,
    UITableConfig,
    GXCheckpointResult,
    CheckpointRunMetacontent,
)
from spark_utils import load_dataframe_from_catalog

if TYPE_CHECKING:
    from great_expectations.checkpoint import CheckpointResult

def run_single_checkpoint(
    context_root_dir: Path,
    checkpoint_name: str,
    table_config: UITableConfig,
    domain: str,
    use_case_name: str,
) -> None:
    """
    Execute a single checkpoint against its DataFrame.

    Args:
        context_root_dir: Path to the downloaded GX context folder.
        checkpoint_name: Name of the checkpoint (e.g., "CUSTOMERS---checkpoint").
        table_config: Full table configuration with table_id, table_name, polaris_path, rules.
        domain: Domain identifier (needed for blob upload path).
        use_case_name: Use Case name (needed for blob upload path).

    Returns:
        None. Results are uploaded to blob storage for Task 3 to process.
    """
    run_timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    run_id = f"{run_timestamp}{settings.NAME_SEPARATOR}{checkpoint_name}"

    logger.info(f"Running checkpoint: {checkpoint_name} (run_id: {run_id})")

    try:
        # Initialize GX context from downloaded folder
        context = gx.get_context(mode="file", context_root_dir=str(context_root_dir))
        logger.info(f"Loaded GX context from: {context_root_dir}")

        # Get the checkpoint
        checkpoint = context.checkpoints.get(checkpoint_name)
        logger.info(f"Retrieved checkpoint: {checkpoint_name}")

        # Load DataFrame from catalog
        df = load_dataframe_from_catalog(table_config.polaris_path)
        logger.info(f"Loaded DataFrame for table: {table_config.polaris_path.table}")

        # Run checkpoint with DataFrame as batch parameter
        # Note: In mock mode (Pandas), we pass a Pandas DataFrame
        # In real mode (Spark), we pass a Spark DataFrame
        checkpoint_result: "CheckpointResult" = checkpoint.run(
            batch_parameters={"dataframe": df},
        )

        logger.success(
            f"Checkpoint completed: {checkpoint_name}, success={checkpoint_result.success}"
        )

        # Convert result to dict for parsing
        checkpoint_result_dict = json.loads(checkpoint_result.describe())

        # Build our custom run metadata (i.e., metacontent)
        checkpoint_run_metacontent = CheckpointRunMetacontent(
            run_id=run_id,
            run_timestamp=run_timestamp,
            checkpoint_name=checkpoint_name,
            table_config=table_config,
        )

        # Parse into GXCheckpointResult Pydantic model
        checkpoint_result_dict["checkpoint_run_metacontent"] = checkpoint_run_metacontent.model_dump()
        gx_checkpoint_result = GXCheckpointResult.model_validate(checkpoint_result_dict)

        # Upload result to blob (serialize model to dict)
        result_blob_path = upload_checkpoint_result(
            domain=domain,
            use_case_name=use_case_name,
            checkpoint_name=checkpoint_name,
            result_dict=gx_checkpoint_result.model_dump(),
        )
        logger.success(f"Uploaded checkpoint result to: {result_blob_path}")

    except Exception as e:
        logger.exception(f"Checkpoint execution failed: {checkpoint_name}. Error: {e}")
        
        # Upload error result to blob so Task 3 can detect the failure
        # Build minimal checkpoint run metacontent for error tracking
        error_checkpoint_run_metacontent = CheckpointRunMetacontent(
            run_id=run_id,
            run_timestamp=run_timestamp,
            checkpoint_name=checkpoint_name,
            table_config=table_config,
        )
        
        # Build error result dict (minimal structure that Task 3 can parse)
        error_result_dict = {
            "success": False,
            "statistics": {
                "evaluated_validations": 0,
                "success_percent": 0.0,
                "successful_validations": 0,
                "unsuccessful_validations": 0,
            },
            "validation_results": [],
            "checkpoint_run_metacontent": error_checkpoint_run_metacontent.model_dump(),
            "error": str(e),  # Extra field to indicate execution error
        }
        
        try:
            error_blob_path = upload_checkpoint_result(
                domain=domain,
                use_case_name=use_case_name,
                checkpoint_name=checkpoint_name,
                result_dict=error_result_dict,
            )
            logger.warning(f"Uploaded error result to: {error_blob_path}")
        except Exception as upload_error:
            logger.error(f"Failed to upload error result for {checkpoint_name}: {upload_error}")


def run_all_checkpoints(
    domain: str,
    use_case_name: str,
    checkpoints_build_metacontent: list[CheckpointBuildMetacontent],
) -> None:
    """
    Execute all checkpoints for a Use Case in sequence.

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.
        checkpoints_build_metacontent: List of CheckpointBuildMetacontent models from Task 1.
            Each contains checkpoint_name, polaris_path, table_name, table_id, etc.

    Returns:
        None. Results are uploaded to blob storage for Task 3 to process and aggregate.
    """
    logger.info(
        f"Running all checkpoints for Use Case: {domain}/{use_case_name} "
        f"({len(checkpoints_build_metacontent)} checkpoints)"
    )

    # Download GX context from blob
    context_root_dir = download_gx_context(domain, use_case_name)
    logger.info(f"Downloaded GX context to: {context_root_dir}")

    # Build UITableConfig from CheckpointBuildMetacontent
    # Note: CheckpointBuildMetacontent only has subset of fields, so we construct UITableConfig
    # with just the essential fields (table_id, table_name, polaris_path)
    # Column/table rules are not needed for execution (already baked into GX expectations)
    
    # Run each checkpoint
    for metacontent in checkpoints_build_metacontent:
        # Construct minimal UITableConfig from metacontent
        table_config = UITableConfig(
            table_id=metacontent.table_id,
            table_name=metacontent.table_name,
            polaris_path=metacontent.polaris_path,
            table_rules=[],  # Not needed at runtime
            column_rules=[],  # Not needed at runtime
        )
        
        run_single_checkpoint(
            context_root_dir=context_root_dir,
            checkpoint_name=metacontent.checkpoint_name,
            table_config=table_config,
            domain=domain,
            use_case_name=use_case_name,
        )

    # Upload Data Docs (generated by GX during checkpoint runs)
    data_docs_local_path = context_root_dir / "uncommitted" / "data_docs" / "local_site"
    data_docs_blob_path = upload_data_docs(domain, use_case_name, data_docs_local_path)
    logger.info(f"Uploaded Data Docs to: {data_docs_blob_path}")

    logger.success(
        f"Completed all {len(checkpoints_build_metacontent)} checkpoints for Use Case: {domain}/{use_case_name}. "
        f"Results uploaded to blob storage for Task 3 aggregation."
    )


def run_use_case(
    domain: str,
    use_case_name: str,
    checkpoints_build_metacontent_path: str | Path | None = None,
) -> None:
    """
    High-level entry point to run a Use Case.

    If checkpoints_build_metacontent_path is provided, loads metacontent from JSON file.
    Otherwise, attempts to load from blob storage alongside the GX context.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        checkpoints_build_metacontent_path: Optional path to checkpoints_build_metacontent.json.

    Returns:
        None. Results are uploaded to blob storage for Task 3 to aggregate and report.
    """
    logger.info(f"Running Use Case: {domain}/{use_case_name}")

    # Load checkpoint metacontent
    if checkpoints_build_metacontent_path:
        metadata_path = Path(checkpoints_build_metacontent_path)
        with open(metadata_path, "r", encoding=settings.FILE_ENCODING) as f:
            checkpoints_build_metacontent_dict = json.load(f)
        # Parse into Pydantic models
        checkpoints_build_metacontent = [
            CheckpointBuildMetacontent.model_validate(item)
            for item in checkpoints_build_metacontent_dict
        ]
        logger.info(f"Loaded checkpoint metacontent from: {metadata_path}")
    else:
        # TODO: In production, this would be passed via XCom from Task 1
        # For now, we expect it to be provided
        raise ValueError(
            "checkpoints_build_metacontent_path is required. "
            "In Airflow, this comes from Task 1 via XCom."
        )

    run_all_checkpoints(domain, use_case_name, checkpoints_build_metacontent)


# -----------------------------------------------------------------------------
# CLI Entry Point
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Run GX checkpoints for a Use Case (Task 2)"
    )
    parser.add_argument(
        "--domain",
        required=True,
        help="Domain identifier (e.g., enercity_ag)",
    )
    parser.add_argument(
        "--use-case",
        required=True,
        dest="use_case_name",
        help="Use Case name (e.g., finance_gl_checks)",
    )
    parser.add_argument(
        "--checkpoint-metadata",
        required=True,
        dest="checkpoints_build_metacontent_path",
        help="Path to checkpoints_build_metacontent.json from Task 1",
    )

    args = parser.parse_args()

    try:
        # Load checkpoint metacontent
        with open(args.checkpoints_build_metacontent_path, "r", encoding=settings.FILE_ENCODING) as f:
            checkpoints_build_metacontent_dict = json.load(f)
        # Parse into Pydantic models
        checkpoints_build_metacontent = [
            CheckpointBuildMetacontent.model_validate(item)
            for item in checkpoints_build_metacontent_dict
        ]

        # Run all checkpoints (no return value, results uploaded to blob)
        run_all_checkpoints(
            domain=args.domain,
            use_case_name=args.use_case_name,
            checkpoints_build_metacontent=checkpoints_build_metacontent,
        )

        print(f"\nSUCCESS: Completed all checkpoints for Use Case: {args.domain}/{args.use_case_name}")
        print("Results have been uploaded to blob storage.")
        print("Run Task 3 (gx_postprocessor.py) to aggregate results and generate summary.")

    except Exception as e:
        logger.exception(f"Failed to run Use Case: {e}")
        print(f"\nERROR: Failed to run Use Case: {e}")
        raise SystemExit(1)
