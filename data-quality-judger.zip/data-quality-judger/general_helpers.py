
import os
import stat
from pathlib import Path
import shutil


def remove_dir_or_file(path: Path):
    if path.exists():
        try:
            shutil.rmtree(path)
        except PermissionError:
            # in case PermissionError occurs for any reason, this should enable dir removal. 
            def remove_readonly(func, path, _):
                """Clear the readonly bit and reattempt the removal."""
                os.chmod(path, stat.S_IWRITE)
                func(path)
            shutil.rmtree(path, onexc=remove_readonly)
