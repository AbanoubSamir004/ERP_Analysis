"""
Blob Storage Utilities Module

Provides functions for uploading/downloading GX context and results to/from blob storage.
Supports both Azure Blob Storage (production) and local mock directory (development).

The mock mode uses `data/mock_adls/` to simulate Azure Blob Storage structure.
Toggle via MOCK_ADLS environment variable (default: True).

"""

import json
import shutil
from pathlib import Path

from custom_logger import logger
from env_config import settings
from general_helpers import remove_dir_or_file


def _get_shortened_names(domain: str, use_case_name: str) -> tuple[str, str]:
    """
    Get shortened domain and use_case_name for Windows compatibility.
    
    Returns first letter (capitalized) of each name.
    
    Args:
        domain: Domain identifier
        use_case_name: Use case name
    
    Returns:
        Tuple of (shortened_domain, shortened_use_case)
    """
    shortened_domain = domain[0].upper() if domain else "X"
    shortened_use_case = use_case_name[0].upper() if use_case_name else "X"
    return shortened_domain, shortened_use_case


def get_use_case_blob_path(domain: str, use_case_name: str, shorten_names_on_windows: bool = False) -> Path:
    """
    Generate blob storage path for a use case, with automatic shortening on Windows
    to avoid the 260-character path length limitation.
    
    On Windows, if the resulting path would exceed 260 characters, the domain and
    use_case_name are shortened to their first letters (capitalized) to prevent
    FileNotFoundError during file operations.
    
    Args:
        domain: Domain identifier
        use_case_name: Use case name
        shorten_names_on_windows: If False, then don't shorten even if on Windows.
    
    Returns:
        Path object: {MOCK_ADLS_DIR}/{domain}/{use_case_name} or shortened version
    
    Examples:
        Normal: MOCK_ADLS_DIR / "enercity_ag/finance_gl_checks"
        Shortened (Windows, long path): MOCK_ADLS_DIR / "E/F"
    """
    base_path = settings.MOCK_ADLS_DIR / f"{domain}/{use_case_name}"
    
    # Windows MAX_PATH limitation is 260 characters
    if shorten_names_on_windows and settings.IS_WINDOWS_OS: # and len(str(base_path)) > 260
        # Shorten to first letter of domain and use_case_name (capitalized)
        shortened_domain, shortened_use_case = _get_shortened_names(domain, use_case_name)
        shortened_path = settings.MOCK_ADLS_DIR / f"{shortened_domain}/{shortened_use_case}"
        return shortened_path
    
    return base_path

def download_gx_context(
    domain: str,
    use_case_name: str,
) -> Path:
    """
    Download GX context folder from blob storage to a local path.

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.

    Returns:
        Path to the downloaded gx/ folder.

    Raises:
        FileNotFoundError: If the context does not exist in blob storage.
    """
    context_root_dir = settings.CONTEXT_ROOT_DIR

    if settings.MOCK_ADLS:
        return _download_gx_context_from_mock_adls(domain, use_case_name, context_root_dir)
    else:
        return _download_gx_context_from_adls(domain, use_case_name, context_root_dir)


def _download_gx_context_from_mock_adls(
    domain: str,
    use_case_name: str,
    context_root_dir: Path,
) -> Path:
    """
    Download GX context from mock ADLS (local directory).

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        context_root_dir: Local directory to download to.

    Returns:
        Path to the downloaded gx/ folder.

    Raises:
        FileNotFoundError: If the context does not exist.
    """
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    source_path = use_case_path / "gx"

    if not source_path.exists():
        logger.error(f"GX context not found at: {source_path}")
        raise FileNotFoundError(f"GX context not found at: {source_path}")

    dest_path = context_root_dir
    
    # Remove path if already exists
    remove_dir_or_file(dest_path)

    shutil.copytree(source_path, dest_path)
    logger.success(f"Downloaded GX context from mock ADLS: {source_path} -> {dest_path}")
    return dest_path


def _download_gx_context_from_adls(
    domain: str,
    use_case_name: str,
    context_root_dir: Path,
) -> Path:
    """
    Download GX context from Azure Blob Storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        context_root_dir: Local directory to download to.

    Returns:
        Path to the downloaded gx/ folder.
    """
    from azure.storage.blob import BlobServiceClient

    if not settings.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required when MOCK_ADLS=False")

    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )
    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    use_case_prefix = get_use_case_blob_path(domain, use_case_name)
    blob_prefix = f"{use_case_prefix}/gx/"
    dest_path = context_root_dir
    dest_path.mkdir(parents=True, exist_ok=True)

    # List and download all blobs with the prefix
    blobs = container_client.list_blobs(name_starts_with=blob_prefix)
    for blob in blobs:
        # Get relative path from the prefix
        relative_path = blob.name[len(blob_prefix):]
        if not relative_path:
            continue

        local_file_path = dest_path / relative_path
        local_file_path.parent.mkdir(parents=True, exist_ok=True)

        blob_client = container_client.get_blob_client(blob.name)
        with open(local_file_path, "wb") as f:
            download_stream = blob_client.download_blob()
            f.write(download_stream.readall())

    logger.success(f"Downloaded GX context from ADLS: {blob_prefix} -> {dest_path}")
    return dest_path


def upload_gx_context(
    domain: str,
    use_case_name: str,
    context_root_dir: str | Path,
) -> str:
    """
    Upload GX context folder to blob storage.

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.
        context_root_dir: Path to the local gx/ folder.

    Returns:
        Blob path where the context was uploaded.
    """
    context_root_dir = Path(context_root_dir)

    if settings.MOCK_ADLS:
        return _upload_gx_context_to_mock_adls(domain, use_case_name, context_root_dir)
    else:
        return _upload_gx_context_to_adls(domain, use_case_name, context_root_dir)


def _upload_gx_context_to_mock_adls(
    domain: str,
    use_case_name: str,
    context_root_dir: Path,
) -> str:
    """
    Upload GX context to mock ADLS (local directory).

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        context_root_dir: Path to the local gx/ folder.

    Returns:
        Blob path where the context was uploaded.
    """
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    dest_path = use_case_path / "gx"

    # Use dirs_exist_ok=True to copy contents even if dest exists
    shutil.copytree(context_root_dir, dest_path, dirs_exist_ok=True)
    logger.success(f"Uploaded GX context to mock ADLS: {context_root_dir} -> {dest_path}")
    return dest_path


def _upload_gx_context_to_adls(
    domain: str,
    use_case_name: str,
    context_root_dir: Path,
) -> str:
    """
    Upload GX context to Azure Blob Storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        context_root_dir: Path to the local gx/ folder.

    Returns:
        Blob path prefix where files were uploaded.
    """
    from azure.storage.blob import BlobServiceClient

    if not settings.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required when MOCK_ADLS=False")

    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )
    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    blob_prefix = get_use_case_blob_path(domain, use_case_name)

    # Upload all files in the local context folder
    for local_file in context_root_dir.rglob("*"):
        if local_file.is_file():
            relative_path = local_file.relative_to(context_root_dir)
            blob_name = f"{blob_prefix}/{relative_path.as_posix()}"

            blob_client = container_client.get_blob_client(blob_name)
            with open(local_file, "rb") as f:
                blob_client.upload_blob(f, overwrite=True)

    logger.success(f"Uploaded GX context to ADLS: {context_root_dir} -> {blob_prefix}")
    return blob_prefix


def upload_checkpoint_result(
    domain: str,
    use_case_name: str,
    checkpoint_name: str,
    result_dict: dict,
) -> Path:
    """
    Upload checkpoint result JSON to blob storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        checkpoint_name: Name of the checkpoint (e.g., "CUSTOMERS---checkpoint").
        result_dict: The checkpoint result as a dictionary.

    Returns:
        Blob path where the result was uploaded.
    """
    if settings.MOCK_ADLS:
        return _upload_checkpoint_result_to_mock_adls(
            domain, use_case_name, checkpoint_name, result_dict
        )
    else:
        return _upload_checkpoint_result_to_adls(
            domain, use_case_name, checkpoint_name, result_dict
        )


def _upload_checkpoint_result_to_mock_adls(
    domain: str,
    use_case_name: str,
    checkpoint_name: str,
    result_dict: dict,
) -> Path:
    """
    Upload checkpoint result to mock ADLS (local directory).

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        checkpoint_name: Name of the checkpoint.
        result_dict: The checkpoint result as a dictionary.

    Returns:
        Blob path where the result was uploaded.
    """
    result_filename = f"{checkpoint_name}.json"
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    dest_dir = use_case_path / "gx_output" / "checkpoint_results"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_file = dest_dir / result_filename

    with open(dest_file, "w", encoding=settings.FILE_ENCODING) as f:
        json.dump(result_dict, f, indent=2, default=str)

    logger.info(f"Uploaded checkpoint result to mock ADLS: {dest_file}")
    return dest_file


def _upload_checkpoint_result_to_adls(
    domain: str,
    use_case_name: str,
    checkpoint_name: str,
    result_dict: dict,
) -> Path:
    """
    Upload checkpoint result to Azure Blob Storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        checkpoint_name: Name of the checkpoint.
        result_dict: The checkpoint result as a dictionary.

    Returns:
        Blob path where the result was uploaded.
    """
    from azure.storage.blob import BlobServiceClient

    if not settings.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required when MOCK_ADLS=False")

    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )
    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    use_case_prefix = get_use_case_blob_path(domain, use_case_name)
    blob_name = use_case_prefix / "gx_output" / "checkpoint_results" / f"{checkpoint_name}.json"
    blob_client = container_client.get_blob_client(blob_name)

    json_content = json.dumps(result_dict, indent=2, default=str)
    blob_client.upload_blob(json_content, overwrite=True)

    logger.success(f"Uploaded checkpoint result to ADLS: {blob_name}")
    return Path(blob_name)


def download_checkpoint_results(
    domain: str,
    use_case_name: str,
    local_path: str | Path,
) -> Path:
    """
    Download all checkpoint result JSON files from blob storage to local path.

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.
        local_path: Local directory to download to.

    Returns:
        Path to the local checkpoint_results directory.

    Raises:
        FileNotFoundError: If the checkpoint_results directory does not exist in blob.
    """
    local_path = Path(local_path)

    if settings.MOCK_ADLS:
        return _download_checkpoint_results_from_mock_adls(domain, use_case_name, local_path)
    else:
        return _download_checkpoint_results_from_adls(domain, use_case_name, local_path)


def _download_checkpoint_results_from_mock_adls(
    domain: str,
    use_case_name: str,
    local_path: Path,
) -> Path:
    """
    Download checkpoint results from mock ADLS (local directory).

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_path: Local directory to download to.

    Returns:
        Path to the local checkpoint_results directory.

    Raises:
        FileNotFoundError: If the checkpoint_results directory does not exist.
    """
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    source_dir = use_case_path / "gx_output" / "checkpoint_results"

    if not source_dir.exists():
        logger.error(f"Checkpoint results not found at: {source_dir}")
        raise FileNotFoundError(f"Checkpoint results not found at: {source_dir}")

    dest_dir = local_path / "gx_output" / "checkpoint_results"
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Copy all JSON files
    for json_file in source_dir.glob("*.json"):
        dest_file = dest_dir / json_file.name
        shutil.copy2(json_file, dest_file)

    logger.success(f"Downloaded checkpoint results from mock ADLS: {source_dir} -> {dest_dir}")
    return dest_dir


def _download_checkpoint_results_from_adls(
    domain: str,
    use_case_name: str,
    local_path: Path,
) -> Path:
    """
    Download checkpoint results from Azure Blob Storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_path: Local directory to download to.

    Returns:
        Path to the local checkpoint_results directory.
    """
    from azure.storage.blob import BlobServiceClient

    if not settings.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required when MOCK_ADLS=False")

    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )
    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    use_case_prefix = get_use_case_blob_path(domain, use_case_name)
    blob_prefix = f"{use_case_prefix}/gx_output/checkpoint_results/"

    dest_dir = local_path / "gx_output" / "checkpoint_results"
    dest_dir.mkdir(parents=True, exist_ok=True)

    # List and download all blobs with the prefix
    blobs = container_client.list_blobs(name_starts_with=blob_prefix)
    downloaded_count = 0
    for blob in blobs:
        if blob.name.endswith(".json"):
            filename = Path(blob.name).name
            local_file_path = dest_dir / filename

            blob_client = container_client.get_blob_client(blob.name)
            with open(local_file_path, "wb") as f:
                download_stream = blob_client.download_blob()
                f.write(download_stream.readall())
            downloaded_count += 1

    logger.success(f"Downloaded {downloaded_count} checkpoint results from ADLS: {blob_prefix} -> {dest_dir}")
    return dest_dir




def upload_data_docs(
    domain: str,
    use_case_name: str,
    local_docs_path: str | Path,
) -> Path:
    """
    Upload Data Docs HTML folder to blob storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_docs_path: Path to the local data_docs/local_site/ folder.

    Returns:
        Blob path where the docs were uploaded.
    """
    local_docs_path = Path(local_docs_path)

    if settings.MOCK_ADLS:
        return _upload_data_docs_to_mock_adls(domain, use_case_name, local_docs_path)
    else:
        return _upload_data_docs_to_adls(domain, use_case_name, local_docs_path)


def _upload_data_docs_to_mock_adls(
    domain: str,
    use_case_name: str,
    local_docs_path: Path,
) -> Path:
    """
    Upload Data Docs to mock ADLS (local directory).

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_docs_path: Path to the local data_docs/local_site/ folder.

    Returns:
        Blob path where the docs were uploaded.
    """
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    dest_path = use_case_path / "gx_output" / "data_docs" / "local_site"

    if dest_path.exists():
        remove_dir_or_file(dest_path)

    if local_docs_path.exists():
        shutil.copytree(local_docs_path, dest_path)
        logger.info(f"Uploaded Data Docs to mock ADLS: {local_docs_path} -> {dest_path}")
    else:
        logger.warning(f"Data Docs not found at: {local_docs_path}")

    return use_case_path / "gx_output" / "data_docs" / "local_site"


def _upload_data_docs_to_adls(
    domain: str,
    use_case_name: str,
    local_docs_path: Path,
) -> Path:
    """
    Upload Data Docs to Azure Blob Storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_docs_path: Path to the local data_docs/local_site/ folder.

    Returns:
        Blob path prefix where files were uploaded.
    """
    from azure.storage.blob import BlobServiceClient

    if not settings.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required when MOCK_ADLS=False")

    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )
    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    use_case_prefix = get_use_case_blob_path(domain, use_case_name)
    blob_prefix = use_case_prefix / "gx_output" / "data_docs" / "local_site"

    if not local_docs_path.exists():
        logger.warning(f"Data Docs not found at: {local_docs_path}")
        return blob_prefix

    # Upload all files in the data docs folder
    for local_file in local_docs_path.rglob("*"):
        if local_file.is_file():
            relative_path = local_file.relative_to(local_docs_path)
            blob_name = f"{blob_prefix}/{relative_path.as_posix()}"

            blob_client = container_client.get_blob_client(blob_name)
            with open(local_file, "rb") as f:
                blob_client.upload_blob(f, overwrite=True)

    logger.info(f"Uploaded Data Docs to ADLS: {local_docs_path} -> {blob_prefix}")
    return blob_prefix


# TODO: implement this in a later sprint
def download_use_case_config(
    domain: str,
    use_case_name: str,
    local_path: str | Path,
) -> Path:
    """
    Download Use Case JSON config from blob storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_path: Local directory to download to.

    Returns:
        Path to the downloaded JSON file.

    Raises:
        FileNotFoundError: If the config does not exist.
    """
    local_path = Path(local_path)

    if settings.MOCK_ADLS:
        return _download_use_case_config_from_mock_adls(domain, use_case_name, local_path)
    else:
        return _download_use_case_config_from_adls(domain, use_case_name, local_path)


def _download_use_case_config_from_mock_adls(
    domain: str,
    use_case_name: str,
    local_path: Path,
) -> Path:
    """
    Download Use Case JSON config from mock ADLS (local directory).

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_path: Local directory to download to.

    Returns:
        Path to the downloaded JSON file.

    Raises:
        FileNotFoundError: If the config does not exist.
    """
    config_filename = "use_case_config.json"
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    source_file = use_case_path / "user_input" / config_filename

    if not source_file.exists():
        logger.error(f"Use Case config not found at: {source_file}")
        raise FileNotFoundError(f"Use Case config not found at: {source_file}")

    dest_dir = local_path / "user_input"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_file = dest_dir / config_filename

    shutil.copy2(source_file, dest_file)
    logger.info(f"Downloaded Use Case config from mock ADLS: {source_file} -> {dest_file}")
    return dest_file


def _download_use_case_config_from_adls(
    domain: str,
    use_case_name: str,
    local_path: Path,
) -> Path:
    """
    Download Use Case JSON config from Azure Blob Storage.

    Args:
        domain: Domain identifier.
        use_case_name: Name of the Use Case.
        local_path: Local directory to download to.

    Returns:
        Path to the downloaded JSON file.
    """
    from azure.storage.blob import BlobServiceClient

    if not settings.AZURE_STORAGE_CONNECTION_STRING:
        raise ValueError("AZURE_STORAGE_CONNECTION_STRING is required when MOCK_ADLS=False")

    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )
    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    use_case_prefix = get_use_case_blob_path(domain, use_case_name)
    blob_name = f"{use_case_prefix}/user_input/use_case_config.json"
    blob_client = container_client.get_blob_client(blob_name)

    dest_dir = local_path / "user_input"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_file = dest_dir / "use_case_config.json"

    try:
        with open(dest_file, "wb") as f:
            download_stream = blob_client.download_blob()
            f.write(download_stream.readall())
    except Exception as e:
        logger.error(f"Failed to download Use Case config: {e}")
        raise FileNotFoundError(f"Use Case config not found at: {blob_name}") from e

    logger.info(f"Downloaded Use Case config from ADLS: {blob_name} -> {dest_file}")
    return dest_file
