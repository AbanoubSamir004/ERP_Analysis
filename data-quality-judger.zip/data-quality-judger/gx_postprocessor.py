"""
GX Postprocessor Module (Task 3)

Processes GX checkpoint results after Task 2 completes.
Implements Approach D: Sequential Task 3 (Simplified Single Task).

This module handles:
1. Parse checkpoint results from blob storage
2. Persist expectation-level results to Polaris DQ results table
3. Aggregate into UseCaseSummaryResult
4. Persist summary row to Polaris DQ summary table
5. Send email notification with summary

Architecture:
- Task 3 runs after all checkpoints complete in Task 2
- Receives checkpoint_results/ directory path via XCom
- Processes all checkpoint JSONs sequentially
- Writes results to Polaris/Snowflake tables
- Sends email notification at the end

"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from custom_logger import logger
from env_config import settings
from blob_utils import get_use_case_blob_path
from gx_helpers import generate_expectation_description
from pydantic_models import (
    GXCheckpointResult,
    FailedExpectationDetail,
    TableValidationSummary,
    UseCaseSummaryResult,
)


# -----------------------------------------------------------------------------
# Step 3.1: Parse Checkpoint Results
# -----------------------------------------------------------------------------


def list_checkpoint_result_files(
    domain: str,
    use_case_name: str,
) -> list[Path]:
    """
    List all checkpoint result JSON files in the gx_output/checkpoint_results/ directory.

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.

    Returns:
        List of Path objects for each checkpoint result JSON file.

    Raises:
        FileNotFoundError: If the checkpoint_results directory does not exist.
    """
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    checkpoint_results_dir = use_case_path / "gx_output" / "checkpoint_results"

    if not checkpoint_results_dir.exists():
        logger.error(f"Checkpoint results directory not found: {checkpoint_results_dir}")
        raise FileNotFoundError(
            f"Checkpoint results directory not found: {checkpoint_results_dir}"
        )

    json_files = list(checkpoint_results_dir.glob("*.json"))
    logger.info(f"Found {len(json_files)} checkpoint result files in {checkpoint_results_dir}")
    return json_files


def parse_checkpoint_result(result_path: Path) -> GXCheckpointResult:
    """
    Parse a single checkpoint result JSON file into a Pydantic model.

    Args:
        result_path: Path to the checkpoint result JSON file.

    Returns:
        GXCheckpointResult Pydantic model.

    Raises:
        ValueError: If the JSON is invalid or doesn't match expected schema.
    """
    logger.debug(f"Parsing checkpoint result: {result_path.name}")

    with open(result_path, "r", encoding=settings.FILE_ENCODING) as f:
        result_dict = json.load(f)

    # Parse into Pydantic model (validates schema)
    checkpoint_result = GXCheckpointResult.model_validate(result_dict)
    checkpoint_name = checkpoint_result.checkpoint_run_metacontent.checkpoint_name
    logger.debug(f"Parsed checkpoint result: {checkpoint_name}")

    return checkpoint_result


def parse_all_checkpoint_results(
    domain: str,
    use_case_name: str,
) -> list[GXCheckpointResult]:
    """
    Parse all checkpoint result JSON files for a Use Case.

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.

    Returns:
        List of GXCheckpointResult Pydantic models.
    """
    result_files = list_checkpoint_result_files(domain, use_case_name)
    checkpoint_results = []

    for result_path in result_files:
        try:
            result = parse_checkpoint_result(result_path)
            checkpoint_results.append(result)
        except Exception as e:
            logger.error(f"Failed to parse {result_path.name}: {e}")
            # Continue processing other files
            continue

    logger.info(f"Successfully parsed {len(checkpoint_results)} checkpoint results")
    return checkpoint_results


# -----------------------------------------------------------------------------
# Step 3.2: Transform to Result Rows (for Polaris persistence)
# -----------------------------------------------------------------------------


def transform_to_result_rows(
    checkpoint_result: GXCheckpointResult,
    summary_id: Optional[int] = None,
) -> list[dict]:
    """
    Transform a checkpoint result into rows for Polaris DQ results table.

    Each expectation in the checkpoint becomes one row.

    Args:
        checkpoint_result: The parsed GXCheckpointResult.
        summary_id: Optional FK to tbl_DQ_Judger_Summary_Results.

    Returns:
        List of dicts, each representing a row for the results table.
    """
    rows: list[dict] = []
    run_metacontent = checkpoint_result.checkpoint_run_metacontent
    table_config = run_metacontent.table_config

    for validation_result in checkpoint_result.validation_results:
        for expectation_result in validation_result.results:
            expectation_config = expectation_result.expectation_config
            result = expectation_result.result
            meta = expectation_config.meta or {}

            checkpoint_name = run_metacontent.checkpoint_name

            row = {
                # Run info
                "run_id": run_metacontent.run_id,
                "run_timestamp": run_metacontent.run_timestamp,
                # Use case info
                "use_case_name": meta.get("use_case_name", ""),
                "use_case_domain": meta.get("domain", ""),
                "use_case_version": meta.get("version", ""),
                # Table info
                "table_id": table_config.table_id,
                "table_name": table_config.table_name,
                "polaris_catalog": table_config.polaris_path.catalog,
                "polaris_namespace": table_config.polaris_path.namespace,
                "polaris_table": table_config.polaris_path.table,
                # Expectation info
                "rule_id": meta.get("rule_id"),
                "expectation_type": expectation_config.type,
                "dq_dimension": meta.get("dq_dimension", ""),
                "severity": expectation_config.kwargs.get("severity", "error"),
                "description": meta.get("description", ""),
                "column_name": expectation_config.kwargs.get("column"),
                "parameters": json.dumps(meta.get("original_parameters", {})),
                # Result info
                "success": expectation_result.success,
                "element_count": result.get("element_count") if result else None,
                "unexpected_count": result.get("unexpected_count") if result else None,
                "unexpected_percent": result.get("unexpected_percent") if result else None,
                "missing_count": result.get("missing_count") if result else None,
                "missing_percent": result.get("missing_percent") if result else None,
                "unexpected_values_sample": json.dumps(
                    result.get("partial_unexpected_list", [])[:10] if result else []
                ),
                # References
                "checkpoint_name": checkpoint_name,
                "summary_id": summary_id,
            }
            rows.append(row)

    logger.debug(f"Transformed {len(rows)} rows from checkpoint: {run_metacontent.checkpoint_name}")
    return rows


# -----------------------------------------------------------------------------
# Step 3.3: Aggregate to Summary
# -----------------------------------------------------------------------------


def extract_failed_expectation_details(
    checkpoint_result: GXCheckpointResult,
) -> list[FailedExpectationDetail]:
    """
    Extract details of failed expectations from a checkpoint result.

    Args:
        checkpoint_result: The parsed GXCheckpointResult.

    Returns:
        List of FailedExpectationDetail for each failed expectation.
    """
    failed_details: list[FailedExpectationDetail] = []

    for validation_result in checkpoint_result.validation_results:
        for expectation_result in validation_result.results:
            if expectation_result.success:
                continue  # Skip passed expectations

            expectation_config = expectation_result.expectation_config
            result = expectation_result.result
            meta = expectation_config.meta or {}

            # Extract rule_id as int from meta
            rule_id_raw = meta.get("rule_id")
            rule_id: int = int(rule_id_raw) if rule_id_raw is not None else 0

            # Generate human-readable description
            expectation_description = generate_expectation_description(
                expectation_config.type,
                expectation_config.kwargs
            )

            # Extract sample unexpected values
            sample_values = None
            if result:
                partial_list = result.get("partial_unexpected_list")
                if partial_list:
                    sample_values = partial_list[:5]  # First 5 values

            failed_detail = FailedExpectationDetail(
                rule_id=rule_id,
                expectation_name=expectation_config.type,
                expectation_description=expectation_description,
                column=expectation_config.kwargs.get("column"),
                unexpected_count=result.get("unexpected_count") if result else None,
                unexpected_percent=result.get("unexpected_percent") if result else None,
                sample_unexpected_values=sample_values,
            )
            failed_details.append(failed_detail)

    return failed_details


def create_table_validation_summary(
    checkpoint_result: GXCheckpointResult,
) -> TableValidationSummary:
    """
    Create a TableValidationSummary from a checkpoint result.

    Args:
        checkpoint_result: The parsed GXCheckpointResult.

    Returns:
        TableValidationSummary with metrics for this table.
    """
    run_metacontent = checkpoint_result.checkpoint_run_metacontent
    table_config = run_metacontent.table_config

    # Check for error in checkpoint result (error field from error JSON upload)
    error_message: str | None = None
    if hasattr(checkpoint_result, "error") and checkpoint_result.error:
        error_message = str(checkpoint_result.error)

    # Aggregate statistics across all validation results
    total_expectations = 0
    passed_expectations = 0
    failed_expectations = 0

    for validation_result in checkpoint_result.validation_results:
        stats = validation_result.statistics
        total_expectations += stats.evaluated_expectations
        passed_expectations += stats.successful_expectations
        failed_expectations += stats.unsuccessful_expectations

    # Calculate success percent
    success_percent = 0.0
    if total_expectations > 0:
        success_percent = (passed_expectations / total_expectations) * 100.0

    # Extract failed expectation details
    failed_expectation_details = extract_failed_expectation_details(checkpoint_result)

    # Determine overall success for this table
    # A table passes if no expectations failed AND no errors occurred
    success = checkpoint_result.success and error_message is None

    return TableValidationSummary(
        table_id=table_config.table_id,
        displayed_table_name=table_config.table_name,
        catalog=table_config.polaris_path.catalog,
        namespace=table_config.polaris_path.namespace,
        table=table_config.polaris_path.table,
        success=success,
        total_expectations=total_expectations,
        passed_expectations=passed_expectations,
        failed_expectations=failed_expectations,
        success_percent=success_percent,
        error_message=error_message,
        checkpoint_run_id=run_metacontent.run_id,
        failed_expectation_details=failed_expectation_details,
    )


def aggregate_to_summary(
    checkpoint_results: list[GXCheckpointResult],
    domain: str,
    use_case_name: str,
) -> UseCaseSummaryResult:
    """
    Aggregate checkpoint results into a UseCaseSummaryResult.

    Args:
        checkpoint_results: List of parsed GXCheckpointResult models.
        domain: Domain identifier.
        use_case_name: Name of the Use Case.

    Returns:
        UseCaseSummaryResult with aggregated metrics.
    """
    table_summaries: list[TableValidationSummary] = []
    passed_tables = 0
    failed_tables = 0

    for checkpoint_result in checkpoint_results:
        table_summary = create_table_validation_summary(checkpoint_result)
        table_summaries.append(table_summary)

        if table_summary.success:
            passed_tables += 1
        else:
            failed_tables += 1

    # Get data docs path from blob storage
    use_case_path = get_use_case_blob_path(domain, use_case_name, shorten_names_on_windows=True)
    data_docs_path = str(use_case_path / "gx_output" / "data_docs" / "local_site")

    # Generate run timestamp
    run_timestamp = datetime.now(timezone.utc).isoformat()

    summary = UseCaseSummaryResult(
        domain=domain,
        use_case_name=use_case_name,
        total_tables=len(checkpoint_results),
        passed_tables=passed_tables,
        failed_tables=failed_tables,
        table_results=table_summaries,
        data_docs_path=data_docs_path,
        run_timestamp=run_timestamp,
    )

    logger.info(f"Aggregated summary: {passed_tables} passed, {failed_tables} failed")
    return summary


# -----------------------------------------------------------------------------
# Main Entry Point: process_checkpoint_results (Task 3)
# -----------------------------------------------------------------------------


def process_checkpoint_results(
    domain: str,
    use_case_name: str,
    recipients: Optional[list[str]] = None,
) -> UseCaseSummaryResult:
    """
    Main entry point for Task 3: Process all checkpoint results.

    This function orchestrates all steps of Task 3:
    1. Parse checkpoint results from blob storage
    2. Persist expectation-level results to tbl_DQ_Judger_Results
    3. Aggregate into UseCaseSummaryResult
    4. Persist summary row to tbl_DQ_Judger_Summary_Results
    5. Send email notification

    Args:
        domain: Domain identifier (e.g., "enercity_ag").
        use_case_name: Name of the Use Case.
        recipients: Optional list of email addresses for notification.

    Returns:
        UseCaseSummaryResult with full execution summary.
    """
    # Import persistence functions from spark_utils and alerting from alerting_utils
    from spark_utils import persist_result_rows, persist_summary
    from alerting_utils import send_notification

    logger.info(f"Starting Task 3: Process checkpoint results for {domain}/{use_case_name}")

    # Step 3.1: Parse all checkpoint results
    checkpoint_results = parse_all_checkpoint_results(domain, use_case_name)
    if not checkpoint_results:
        logger.warning("No checkpoint results to process")
        # Return empty summary
        run_timestamp = datetime.now(timezone.utc).isoformat()
        return UseCaseSummaryResult(
            domain=domain,
            use_case_name=use_case_name,
            total_tables=0,
            passed_tables=0,
            failed_tables=0,
            table_results=[],
            data_docs_path="",
            run_timestamp=run_timestamp,
        )

    # Step 3.2: Aggregate to summary
    summary = aggregate_to_summary(checkpoint_results, domain, use_case_name)
    
    # Step 3.3: Persist summary to get summary_id
    summary_id = persist_summary(summary)

    # Step 3.4: Transform and persist result rows
    all_rows: list[dict] = []
    for checkpoint_result in checkpoint_results:
        rows = transform_to_result_rows(checkpoint_result, summary_id=summary_id)
        all_rows.extend(rows)

    if all_rows:
        persist_result_rows(all_rows)
    logger.info(f"Persisted {len(all_rows)} result rows total")

    # Step 3.5: Send notification
    send_notification(summary, recipients)

    logger.success(f"Task 3 completed: {summary.to_log_string()}")
    return summary


# -----------------------------------------------------------------------------
# CLI Entry Point
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Process GX checkpoint results (Task 3)"
    )
    parser.add_argument(
        "--domain",
        required=True,
        help="Domain identifier (e.g., enercity_ag)",
    )
    parser.add_argument(
        "--use-case",
        required=True,
        dest="use_case_name",
        help="Use Case name (e.g., finance_gl_checks)",
    )
    parser.add_argument(
        "--recipients",
        nargs="*",
        help="Email recipients for notification",
    )

    args = parser.parse_args()

    try:
        result = process_checkpoint_results(
            domain=args.domain,
            use_case_name=args.use_case_name,
            recipients=args.recipients,
        )
        print(f"\n{result.to_log_string()}")
    except Exception as e:
        logger.exception(f"Failed to process checkpoint results: {e}")
        print(f"\nERROR: Failed to process checkpoint results: {e}")
        raise SystemExit(1)
