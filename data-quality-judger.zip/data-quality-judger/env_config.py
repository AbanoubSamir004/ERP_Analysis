"""
Environment Configuration Module

Centralized configuration management using Pydantic Settings.
Loads settings from environment variables, .env file, or defaults.

MAINTENANCE NOTE: If you decide to change the location of this file, then you need to update DQ_JUDGER_DIR accordingly.

"""

import os
from pathlib import Path
from typing import Literal

from pydantic import Field, computed_field, model_validator, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


# This constant specifically is defined at module level, \
# as it's used in pydantic-settings' SettingsConfigDict class 
# before defining the `FILE_ENCODING` class property
# TODO (optional): see if there's a cleaner alternative to this.
_FILE_ENCODING = "utf-8-sig"

# -----------------------------------------------------------------------------
# Environment Settings
# -----------------------------------------------------------------------------

class DQJudgerSettings(BaseSettings):
    """
    DQ Judger environment settings.

    All settings are CAPS to clearly indicate they are configurable via environment.

    IMPORTANT NOTE: 
        1. Check `.env.example` file for an explanation of each setting.
        2. If you'll add path-related attributes, then make sure you modify `create_directories` accordingly.

    Notes regarding how Pydantic Settings works:

    Field value precedence in Pydantic Settings (highest to lowest priority):

    1. CLI arguments (if cli_parse_args is enabled).
    2. Arguments passed to the Settings initializer.
    3. Environment variables.
    4. Variables from a dotenv (.env) file.
    5. Variables from the secrets directory.
    6. Default field values in the DQJudgerSettings model.

    For more details, refer to the Pydantic documentation:
    [https://docs.pydantic.dev/latest/concepts/pydantic_settings/#field-value-priority].
    """

    model_config = SettingsConfigDict(
        # Use absolute path to .env file in data-quality-judger directory
        env_file=Path(__file__).parent / ".env",
        env_file_encoding=_FILE_ENCODING,
        extra="ignore",
        case_sensitive=False,
    )

    # -------------------------------------------------------------------------
    # Production Constants (computed from module location, not configurable)
    # -------------------------------------------------------------------------

    @computed_field
    @property
    def DQ_JUDGER_DIR(self) -> Path:
        """Base directory of the data-quality-judger module."""
        return Path(__file__).parent

    @computed_field
    @property
    def DATA_DIR(self) -> Path:
        """Data directory for mock storage."""
        return self.DQ_JUDGER_DIR / "data"
    
    @computed_field
    @property
    def CONTEXT_ROOT_DIR(self) -> Path:
        """
        Directory for GX context.
        
        I.e., `context_root_dir` parameter in 
        gx.get_context(mode="file", context_root_dir=settings.CONTEXT_ROOT_DIR).
        """
        return self.DQ_JUDGER_DIR / "gx"
    
    @computed_field
    @property
    def DATA_DOCS_DIR(self) -> Path:
        """
        Directory for GX Data Docs.
        """
        return self.CONTEXT_ROOT_DIR / "uncommitted/data_docs/local_site/"

    # Triple hyphen separator for GX artifact names (avoids underscore ambiguity)
    # NOTE 1: we're always deploying on non-windows platforms, so you'll always see
    #         '---' in production.
    # NOTE 2: You should NEVER change this, unless you have a valid reason for doing so.
    @computed_field
    @property
    def NAME_SEPARATOR(self) -> str:
        """
        Separator for GX artifact names.
        Returns '-' if running on Windows OS, otherwise '---'.
        This is done to help get around Windows' 260 max path limit.
        Details: https://discourse.greatexpectations.io/t/updated-file-not-found-error-unable-to-generate-result-json-files-and-data-docs/1671
        """
        return "-" if self.IS_WINDOWS_OS else "---"

    # File encoding for reading/writing files (utf-8-sig handles BOM on Windows/Linux)
    FILE_ENCODING: str = Field(
        default=_FILE_ENCODING,
        description="File encoding for reading/writing files. utf-8-sig handles UTF-8 BOM transparently.",
    )

    # ---------------------------------
    # Azure Blob Storage Configuration
    # ---------------------------------

    AZURE_STORAGE_CONNECTION_STRING: SecretStr | None = Field(
        default=None,
        description="Azure Storage connection string for Blob operations",
    )

    AZURE_STORAGE_CONTAINER_NAME: str = Field(
        default="dq-blob-container",
        description="Azure Blob container name for DQ artifacts",
    )

    # ---------------------------------
    # Polaris Catalog Configuration
    # ---------------------------------
    # NOTE: All of the non-None default values in this section should never change 
    #       unless you have a valid reason for changing them.

    POLARIS_URI: str | None = Field(
        default=None,
        description="Polaris Catalog base URI (e.g., https://<DOMAIN>.snowflakecomputing.com/polaris)",
    )

    POLARIS_CREDENTIAL: SecretStr | None = Field(
        default=None,
        description="Polaris OAuth2 credential string (73-char format: client_id:client_secret)",
    )

    POLARIS_CATALOG_NAME: str | None = Field(
        default=None,
        description="Name of the Iceberg catalog in Polaris",
    )

    POLARIS_DQ_NAMESPACE: str = Field(
        default="dq_results",
        description="Namespace for DQ result tables (tbl_DQ_Judger_Results, tbl_DQ_Judger_Summary_Results)",
    )

    POLARIS_DQ_JUDGER_FULL_RESULTS_TABLE: str = Field(
        default="tbl_DQ_Judger_Results",
        description="Polaris table name for the Judger's full results",
    )

    POLARIS_DQ_JUDGER_SUMMARY_TABLE: str = Field(
        default="tbl_DQ_Judger_Summary_Results",
        description="Polaris table name for the Judger's summary results",
    )

    # ---------------------------------
    # Spark Configuration
    # ---------------------------------

    SPARK_MASTER: str = Field(
        default="local[*]",
        description="Spark master URL (local[*] for local mode)",
    )

    SPARK_APP_NAME: str = Field(
        default="DQ_Judger",
        description="Spark application name",
    )

    # -------------------------------------------------------------------------
    # Toggles (for local development without specific resources, or for debugging)
    # -------------------------------------------------------------------------

    # TODO: Set these to `False` whenever you establish one of these services.

    MOCK_ADLS: bool = Field(
        default=True,
        description="Use local mock_adls directory instead of Azure Blob Storage",
    )

    MOCK_SPARK: bool = Field(
        default=True,
        description="Use Pandas instead of Spark for data loading",
    )

    MOCK_CATALOG: bool = Field(
        default=True,
        description="Use local mock_catalog directory instead of Polaris Catalog",
    )

    MOCK_AIRFLOW_XCOM: bool = Field(
        default=True,
        description="Use local file for Airflow XCom instead of real Airflow XCom",
    )

    MOCK_EMAIL: bool = Field(
        default=True,
        description="Mock email notifications (log to console instead of sending)",
    )

    # NOTE: This should always be kept to "True" unless you have a valid reason for changing it.
    DELETE_LOCAL_GX_CONTEXT_BEFORE_BUILD: bool = Field(
        default=True,
        description=(
            "Whether to delete the existing local GX context directory before building GX artifacts. "
            "Its default is true, since this code will usually be executed in ephemeral "
            "environments that start with an empty `CONTEXT_ROOT_DIR` folder anyways."
        ),
    )

    # NOTE 1: This should always be kept to "False" unless you have a valid reason for changing it.
    # NOTE 2: If this is "True", then DELETE_LOCAL_GX_CONTEXT_BEFORE_BUILD doesn't have any effect,
    #         since this toggle overwrites the local GX context after downloading from Blob Storage.
    DOWNLOAD_BLOB_GX_CONTEXT_BEFORE_BUILD: bool = Field(
        default=False,
        description=(
            "Whether to download existing GX context from Azure Blob Storage before building GX artifacts. "
            "Useful if we want to maintain internal IDs of use case's GX artifacts across different runs."
        ),
    )

    # TODO: change this to "True"
    # This should be "False" while testing locally, and "True" in production.
    CATCH_EXPECTATION_EXCEPTION: bool = Field(
        default=False,
        description=(
            "Whether to catch exceptions during expectation execution. "
            "Useful for debugging failing expectations. "
            "However, in production, it's recommended to set this to True to avoid "
            "halting the entire checkpoint run due to a single expectation failure."
        ),
    )

    # -------------------------------------------------------------------------
    # Local Constants (Mostly related to MOCK logic and toggles for debugging)
    # -------------------------------------------------------------------------

    @computed_field
    @property
    def MOCK_ADLS_DIR(self) -> Path:
        """Mock Azure Blob Storage directory."""
        return self.DATA_DIR / "mock_adls"

    @computed_field
    @property
    def MOCK_CATALOG_DIR(self) -> Path:
        """Mock Polaris Catalog directory."""
        return self.DATA_DIR / "mock_catalog"

    @computed_field
    @property
    def MOCK_AIRFLOW_XCOM_DIR(self) -> Path:
        """Mock Airflow XCom directory."""
        return self.DATA_DIR / "mock_airflow_xcom"

    @computed_field
    @property
    def IS_WINDOWS_OS(self) -> bool:
        """
        Returns True if the script is executed on a Windows platform
        """
        return os.name == "nt"

    # -------------------------------------------------------------------------
    # Logging Configuration
    # -------------------------------------------------------------------------

    LOGGING_LEVEL: Literal["TRACE", "DEBUG", "INFO", "SUCCESS", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="DEBUG",
        description="Logging level for the application (from lowest to highest), noting that 'TRACE' and 'SUCCESS' are exclusive to loguru",
    )

    # -------------------------------------------------------------------------
    # Post Processing After Class is Initialized
    # -------------------------------------------------------------------------

    @model_validator(mode="after")
    def create_directories(self) -> "DQJudgerSettings":
        """
        Create all required directories after model initialization.
        
        Always creates:
        - DQ_JUDGER_DIR (module root)
        - DATA_DIR (data storage)
        - CONTEXT_ROOT_DIR (GX context)
        
        Conditionally creates (based on toggles):
        - MOCK_ADLS_DIR (only if MOCK_ADLS=True)
        - MOCK_CATALOG_DIR (only if MOCK_CATALOG=True)
        - MOCK_AIRFLOW_XCOM_DIR (only if MOCK_AIRFLOW_XCOM=True)
        """
        # Always create these directories
        self.DQ_JUDGER_DIR.mkdir(parents=True, exist_ok=True)
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.CONTEXT_ROOT_DIR.mkdir(parents=True, exist_ok=True)
        
        # Conditionally create mock directories
        if self.MOCK_ADLS:
            self.MOCK_ADLS_DIR.mkdir(parents=True, exist_ok=True)
        
        if self.MOCK_CATALOG:
            self.MOCK_CATALOG_DIR.mkdir(parents=True, exist_ok=True)

        if self.MOCK_AIRFLOW_XCOM:
            self.MOCK_AIRFLOW_XCOM_DIR.mkdir(parents=True, exist_ok=True)
        
        return self


# Singleton instance for easy import
settings = DQJudgerSettings()
