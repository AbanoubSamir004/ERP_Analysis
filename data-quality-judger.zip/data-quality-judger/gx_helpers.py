"""
GX Helpers Module

Provides utility functions for working with Great Expectations:
- Populating expectation suites from configuration
- Transforming UI JSON rules to GX-compatible format
- Grouping rules by DQ dimension

"""
from collections import defaultdict
from typing import TYPE_CHECKING, Any

import great_expectations as gx

from custom_logger import logger
from pydantic_models import (
    UIRule,
    UITableConfig,
    TableMetacontent,
    UseCaseMetacontent,
    TransformedGXRule,
    RuleMeta,
    GXRuleParams,
)

from env_config import settings

# These are for IDE type checking only
if TYPE_CHECKING:
    from great_expectations.core.expectation_suite import ExpectationSuite
    from great_expectations.expectations.expectation import Expectation
    from great_expectations.render import RenderedStringTemplateContent


def transform_ui_rule_to_gx_format(
    rule: UIRule,
    table_metacontent: TableMetacontent,
    use_case_metacontent: UseCaseMetacontent,
    column: str | None = None,
) -> TransformedGXRule:
    """
    Transform a single UI rule definition to GX-compatible format.

    The UI JSON stores meta fields (description, dq_dimension, rule_id) as sibling keys
    to 'parameters'. This function moves them into a 'meta' dict and injects the 'column'
    parameter for column-level expectations. The meta dict includes all context needed
    for Task 3 to reconstruct the full picture without needing the original UI JSON.

    Note: 'severity' stays inside parameters since it's passed to GX.

    Args:
        rule: A UIRule with expectation_type, dq_dimension, description, rule_id, parameters.
        table_metacontent: TableMetacontent with table_id and polaris_path.
        use_case_metacontent: UseCaseMetacontent with use_case_name, domain, version.
        column: Column name to inject for column-level expectations (None for table-level).

    Returns:
        A TransformedGXRule with expectation_type, dq_dimension, and params dict.
    """
    expectation_type = rule.expectation_type
    dq_dimension = rule.dq_dimension
    
    # Build comprehensive meta object for Task 3 to use
    meta = RuleMeta(
        rule_id=rule.rule_id,
        dq_dimension=dq_dimension,
        description=rule.description,
        table_id=table_metacontent.table_id,
        table_name=table_metacontent.polaris_path.table,
        polaris_path=table_metacontent.polaris_path,
        use_case_name=use_case_metacontent.use_case_name,
        domain=use_case_metacontent.domain,
        version=use_case_metacontent.version,
        original_parameters=dict(rule.parameters),
    )
    
    # Construct GXRuleParams with known fields + unknown expectation params via extra='allow'
    params = GXRuleParams(
        meta=meta,
        column=column,
        **rule.parameters,  # Spreads all UI params (severity, mostly, value_set, etc.)
    )

    return TransformedGXRule(
        expectation_type=expectation_type,
        dq_dimension=dq_dimension,
        params=params,
    )


def transform_ui_table_config_to_gx_format(
    table_config: UITableConfig,
    use_case_metacontent: UseCaseMetacontent,
) -> list[TransformedGXRule]:
    """
    Transform all rules for a single table from UI JSON to GX-compatible format.

    Handles both table_rules (no column) and column_rules (with column injection).

    Args:
        table_config: A UITableConfig with polaris_path, table_rules, and column_rules.
        use_case_metacontent: UseCaseMetacontent with use_case_name, owner, version.

    Returns:
        List of TransformedGXRule, each with expectation_type, dq_dimension, and params.
    """
    gx_rules: list[TransformedGXRule] = []
    
    # Build table metacontent for passing to transform function
    table_metacontent = TableMetacontent(
        table_id=table_config.table_id,
        polaris_path=table_config.polaris_path,
    )
    
    # Process table-level rules (includes ColumnPair expectations)
    for rule in table_config.table_rules:
        transformed = transform_ui_rule_to_gx_format(
            rule, table_metacontent, use_case_metacontent, column=None
        )
        gx_rules.append(transformed)
        logger.debug(f"Transformed table rule: {rule.expectation_type} -> {transformed}")
    
    # Process column-level rules
    for column_group in table_config.column_rules:
        columns = column_group.columns
        rules = column_group.rules
        
        for column in columns:
            for rule in rules:
                transformed = transform_ui_rule_to_gx_format(
                    rule, table_metacontent, use_case_metacontent, column=column
                )
                gx_rules.append(transformed)
                logger.debug(f"Transformed column rule: {rule.expectation_type} for column {column}")
    
    return gx_rules


def group_rules_by_dq_dimension(
    gx_rules: list[TransformedGXRule],
) -> dict[str, list[TransformedGXRule]]:
    """
    Group transformed GX rules by their DQ dimension.

    This enables creating one Expectation Suite per DQ dimension,
    resulting in cleaner Data Docs that show results grouped by dimension.

    Args:
        gx_rules: List of TransformedGXRule from transform_ui_table_config_to_gx_format.

    Returns:
        Dict mapping dq_dimension to list of rules for that dimension.
        Example: {"completeness": [...], "uniqueness": [...], "validity": [...]}
    """
    grouped: dict[str, list[TransformedGXRule]] = defaultdict(list)
    
    for rule in gx_rules:
        dimension = rule.dq_dimension
        grouped[dimension].append(rule)
    
    logger.debug(f"Grouped {len(gx_rules)} rules into {len(grouped)} dimensions: {list(grouped.keys())}")
    
    return dict(grouped)


def populate_expectation_suite(
    suite: "ExpectationSuite",
    gx_rules: list[TransformedGXRule],
) -> "ExpectationSuite":
    """
    Populate an Expectation Suite with expectations from transformed rules.

    Args:
        suite: The ExpectationSuite object to populate.
        gx_rules: List of TransformedGXRule from transform_ui_table_config_to_gx_format.

    Returns:
        The populated ExpectationSuite (same object, mutated in place).
    """
    for rule in gx_rules:
        expectation_type = rule.expectation_type
        params = rule.params
        
        try:
            # Dynamically get the expectation class from gx.expectations
            expectation_class = getattr(gx.expectations, expectation_type)
            # Unpack GXRuleParams model to dict for GX constructor
            expectation = expectation_class(**params.model_dump())
            suite.add_expectation(expectation)
            
            logger.info(f"Added expectation: {expectation_type}")
            
        except AttributeError:
            logger.error(f"Expectation type '{expectation_type}' not found in gx.expectations. Skipping.")
        except TypeError as e:
            logger.error(f"TypeError creating expectation '{expectation_type}' with params {params.model_dump()}: {e}")
        except Exception as e:
            logger.error(f"Unexpected error adding expectation '{expectation_type}': {e}")
    
    return suite


def get_asset_name(table_config: UITableConfig) -> str:
    """
    Get a GX asset name from table configuration.

    Uses the table_name field which handles namespace disambiguation
    for duplicate table names in the UI.

    Args:
        table_config: UITableConfig with table_name.

    Returns:
        Asset name string, e.g., "CUSTOMERS" or "sales_schema.INVOICES"
    """
    return table_config.table_name


def get_data_docs_site_name(owner: str, use_case_name: str) -> str:
    """
    Generate a data docs site name based on owner and use case name.

    Args:
        owner: Owner name.
        use_case_name: Use Case name.
    
    Returns:
        Site name string, e.g., "owner---use_case_name---site"
    """
    sep = settings.NAME_SEPARATOR
    return f"{owner}{sep}{use_case_name}{sep}site"


# -----------------------------------------------------------------------------
# Expectation Description Generation
# -----------------------------------------------------------------------------


def generate_expectation_description(expectation_class_name: str, params: dict) -> str:
    """
    Generate English description for an expectation using its prescriptive template.
    
    This function leverages GX's built-in prescriptive renderer to generate
    human-readable descriptions of expectations. The output is suitable for
    notifications (email, Jira) where users need to understand what each rule checks.
    
    Args:
        expectation_class_name: Class name in PascalCase like "ExpectColumnValuesToNotBeNull"
        params: Dictionary of expectation parameters (column, value_set, mostly, etc.)
        
    Returns:
        English description string, e.g.:
        "`status` values must belong to this set: `active` `inactive` `pending`, at least 95% of the time."
        
    Example:
        >>> generate_expectation_description(
        ...     "ExpectColumnValuesToBeInSet",
        ...     {"column": "status", "value_set": ["active", "inactive"], "mostly": 0.95}
        ... )
        "`status` values must belong to this set: `active` `inactive`, at least 95% of the time."
    """
    try:
        # Convert a PascalCased class name like "ExpectColumnValuesToNotBeNull" 
        #   to a snake_cased class name like "expect_column_values_to_not_be_null"
        snake_expectation_class_name = ''.join(
            ['_' + c.lower() if c.isupper() else c for c in expectation_class_name]
        ).lstrip('_')
        
        # Dynamically get the expectation class from gx.expectations
        expectation_class: Expectation = getattr(gx.expectations, expectation_class_name)
        
        # Import ExpectationConfiguration for creating the config object
        from great_expectations.expectations.expectation_configuration import ExpectationConfiguration
        
        # Create expectation configuration
        config = ExpectationConfiguration(
            type=snake_expectation_class_name,
            kwargs=params
        )
        
        # Determine if column name should be included
        include_column_name = "column" in params
        
        # Generate the prescriptive renderer (this does actual substitution)
        rendered_content: list[RenderedStringTemplateContent] = expectation_class._prescriptive_renderer(
            configuration=config,
            runtime_configuration={"include_column_name": include_column_name}
        )
        
        # Extract the template string and substitute parameters
        template_str: str = rendered_content[0].string_template["template"]
        template_params: dict[str, Any] = rendered_content[0].string_template["params"]
        
        # Simple substitution for the template output that initially looks like this 
        # (for ExpectColumnValuesToBeInSet):
        #   $column values must belong to this set: $v__0 $v__1 $v__2, at least $mostly_pct % of the time.
        # to instead look like this:
        #   `status` values must belong to this set: `active` `inactive` `pending`, at least 95% of the time.
        result = template_str
        logger.trace(f"Template string: {result}")
        logger.trace(f"Template params: {template_params}")
        
        for param_name, param_value in template_params.items():
            if param_name.startswith('v_'):
                result = result.replace(f"${param_name}", f"`{param_value}`")
            if "$column " in result and param_name == "column":
                result = result.replace("$column", f"`{param_value}`")
            if "$mostly_pct " in result and param_name == "mostly_pct":
                result = result.replace("$mostly_pct ", str(param_value))
            if f"${param_name}" in result:
                result = result.replace(f"${param_name}", f"`{param_value}`")
        
        return result

    except Exception as e:
        logger.exception(f"Error generating description for {expectation_class_name} with params {params}: {e}")
        return f"Error generating description: {str(e)}"