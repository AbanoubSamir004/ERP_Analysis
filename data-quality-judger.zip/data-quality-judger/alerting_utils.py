"""
Alerting Utilities Module

Provides functions for sending notifications (email, Jira, etc.) about
Data Quality validation results.

Supports both mock mode (logs to console) and production mode
(sends via Outlook/Microsoft Graph API).

Toggle via MOCK_EMAIL environment variable in env_config.py.
"""

from typing import Optional

from custom_logger import logger
from env_config import settings
from pydantic_models import UseCaseSummaryResult


def send_notification(
    summary: UseCaseSummaryResult,
    recipients: Optional[list[str]] = None,
) -> bool:
    """
    Send email notification with Use Case summary.

    Args:
        summary: The UseCaseSummaryResult to include in the email.
        recipients: List of email addresses. If None, uses configured defaults.

    Returns:
        True if email sent successfully, False otherwise.
    """
    if settings.MOCK_EMAIL:
        return _send_notification_mock(summary, recipients)
    else:
        return _send_notification_outlook(summary, recipients)


def _send_notification_mock(
    summary: UseCaseSummaryResult,
    recipients: Optional[list[str]] = None,
) -> bool:
    """
    Mock email notification (logs to console).

    Args:
        summary: The UseCaseSummaryResult to include in the email.
        recipients: List of email addresses.

    Returns:
        Always True (mock).
    """
    status = "PASS" if summary.overall_success else "FAIL"
    subject = f"[DQ {status}] {summary.use_case_name} - {summary.domain}"

    logger.info(f"[MOCK EMAIL] Subject: {subject}")
    logger.info(f"[MOCK EMAIL] Recipients: {recipients or 'default'}")
    logger.info(f"[MOCK EMAIL] Body:\n{summary.to_log_string()}")

    return True


def _send_notification_outlook(
    summary: UseCaseSummaryResult,
    recipients: Optional[list[str]] = None,
) -> bool:
    """
    Send email notification via Outlook.

    Args:
        summary: The UseCaseSummaryResult to include in the email.
        recipients: List of email addresses.

    Returns:
        True if email sent successfully, False otherwise.
    """
    # TODO: Implement Outlook email sending
    # This will use Microsoft Graph API or SMTP depending on environment
    logger.warning("Outlook email sending not yet implemented")
    return _send_notification_mock(summary, recipients)
