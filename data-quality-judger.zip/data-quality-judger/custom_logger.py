"""
Custom Logger Configuration

Configures loguru logger with a standardized format for the DQ Judger.

"""

import sys

from loguru import logger

# -------------------------
# Logger Configuration
# -------------------------
# Remove the default logger's sink
logger.remove()

# Configure logger to output to stderr with a custom format
custom_format = (
    "<green>{time:YYYY-MM-DD HH:mm:ss.SS}</green> | "
    "<level>{level}</level> | "
    "<magenta>{file}</magenta>:<cyan>{line}</cyan> | "
    "<level>{message}</level>"
)

# Add the console sink (i.e., display in terminal) with the custom format
logger.add(
    sys.stderr,
    format=custom_format,
    level="DEBUG",
    backtrace=True,
    diagnose=False,
)
