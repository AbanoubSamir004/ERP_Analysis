"""
Spark Utilities Module

Provides functions for Spark session initialization and DataFrame loading.
Supports both Spark+Polaris (production) and Pandas+local files (development).

The mock mode uses `data/mock_catalog/` to simulate Polaris catalog structure.
Toggle via MOCK_SPARK and MOCK_CATALOG environment variables (default: True).

Mock Catalog Structure:
    data/mock_catalog/
    └── {catalog}/
        └── {namespace}/
            └── {table}.parquet

"""

from pathlib import Path
from typing import TYPE_CHECKING, Union

from custom_logger import logger
from env_config import settings

if TYPE_CHECKING:
    import pandas as pd
    from pyspark.sql import DataFrame as SparkDataFrame
    from pyspark.sql import SparkSession
    from pydantic_models import UseCaseSummaryResult

# Type alias for DataFrame (can be either Pandas or Spark)
DataFrame = Union["pd.DataFrame", "SparkDataFrame"]

# TODO: implement this in a later sprint
def get_or_create_spark_session() -> "SparkSession":
    """
    Get or create a Spark session configured for Polaris/Iceberg.

    Only used when MOCK_SPARK=False. When MOCK_SPARK=True, Pandas is used instead.

    The Spark session is configured with:
    - Iceberg extensions for Apache Iceberg table support
    - Polaris REST catalog integration
    - OAuth2 authentication with vended credentials
    - ADLS FileIO for Azure Data Lake Storage

    Returns:
        SparkSession configured for Iceberg with Polaris catalog.

    Raises:
        ValueError: If required Polaris credentials are missing.
        RuntimeError: If called when MOCK_SPARK=True.
    """
    if settings.MOCK_SPARK:
        logger.warning("get_or_create_spark_session() called but MOCK_SPARK=True. Use Pandas instead.")
        raise RuntimeError(
            "Spark session not available in mock mode. "
            "Use load_dataframe_from_catalog() which handles mock mode."
        )

    from pyspark.sql import SparkSession

    # Check required credentials
    if not settings.POLARIS_CREDENTIAL:
        raise ValueError(
            "POLARIS_CREDENTIAL is required when MOCK_SPARK=False"
        )

    POLARIS_CATALOG_NAME = settings.POLARIS_CATALOG_NAME
    polaris_uri = settings.POLARIS_URI

    # Build Spark session with Iceberg and Polaris configuration
    builder = (
        SparkSession.builder
        .appName(settings.SPARK_APP_NAME)
        .master(settings.SPARK_MASTER)
        # Iceberg extensions
        .config(
            "spark.sql.extensions",
            "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions"
        )
        # Catalog configuration
        .config(f"spark.sql.catalog.{POLARIS_CATALOG_NAME}", "org.apache.iceberg.spark.SparkCatalog")
        .config(f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.type", "rest")
        .config(f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.uri", f"{polaris_uri}/api/catalog") # /v1
        .config(f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.warehouse", POLARIS_CATALOG_NAME)
        .config(f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.scope", "PRINCIPAL_ROLE:ALL")
        # OAuth2 authentication (credential format: client_id:client_secret)
        .config(
            f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.credential",
            settings.POLARIS_CREDENTIAL
        )
        .config(
            f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.oauth2-server-uri",
            f"{polaris_uri}/api/catalog/v1/oauth/tokens"
        )
        # Vended credentials for ADLS access
        .config(
            f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.header.X-Iceberg-Access-Delegation",
            "vended-credentials"
        )
        # Azure ADLS FileIO
        .config(
            f"spark.sql.catalog.{POLARIS_CATALOG_NAME}.io-impl",
            "org.apache.iceberg.azure.adlsv2.ADLSFileIO"
        )
    )

    spark = builder.getOrCreate()
    logger.success(
        f"Spark session created/retrieved: {settings.SPARK_APP_NAME} @ {settings.SPARK_MASTER}, "
        f"catalog: {POLARIS_CATALOG_NAME}"
    )

    return spark


# TODO: implement this in a later sprint
def load_dataframe_from_catalog(
    polaris_path: dict,
    spark: "SparkSession | None" = None,
) -> DataFrame:
    """
    Load a DataFrame from Polaris catalog or mock catalog.

    Args:
        polaris_path: Dict with keys: catalog, namespace, table.
            Example: {"catalog": "enercity_catalog", "namespace": "ag.isu_vertrieb.sales_schema", "table": "CUSTOMERS"}
        spark: SparkSession (required when MOCK_SPARK=False, ignored when True).

    Returns:
        DataFrame (Pandas DataFrame if MOCK_SPARK=True, Spark DataFrame otherwise).

    Raises:
        FileNotFoundError: If the table is not found in mock catalog.
        ValueError: If spark session is missing in non-mock mode.
    """
    catalog = polaris_path.catalog
    namespace = polaris_path.namespace
    table = polaris_path.table

    if settings.MOCK_SPARK or settings.MOCK_CATALOG:
        # Mock mode: load from local parquet file
        return _load_dataframe_from_mock_catalog(catalog, namespace, table)
    else:
        # Real mode: load from Polaris via Spark
        if spark is None:
            raise ValueError("SparkSession is required when MOCK_SPARK=False")
        return _load_dataframe_from_polaris(spark, catalog, namespace, table)


def _load_dataframe_from_mock_catalog(
    catalog: str,
    namespace: str,
    table: str,
) -> "pd.DataFrame":
    """
    Load a DataFrame from the mock catalog (local parquet files).

    Mock catalog structure:
        data/mock_catalog/{catalog}/{namespace}/{table}.parquet

    Args:
        catalog: Catalog name (e.g., "enercity_catalog").
        namespace: Namespace path (e.g., "ag.isu_vertrieb.sales_schema").
        table: Table name (e.g., "CUSTOMERS").

    Returns:
        Pandas DataFrame.

    Raises:
        FileNotFoundError: If the parquet file is not found.
    """
    import pandas as pd

    # Convert namespace dots to path separators
    namespace_path = namespace.replace(".", "/")
    parquet_path = settings.MOCK_CATALOG_DIR / catalog / namespace_path / f"{table}.parquet"

    if not parquet_path.exists():
        logger.error(f"Mock catalog table not found: {parquet_path}")
        raise FileNotFoundError(f"Mock catalog table not found: {parquet_path}")

    df = pd.read_parquet(parquet_path)
    logger.success(f"Loaded DataFrame from mock catalog: {parquet_path} ({len(df)} rows)")

    return df


def _load_dataframe_from_polaris(
    spark: "SparkSession",
    catalog: str,
    namespace: str,
    table: str,
) -> "SparkDataFrame":
    """
    Load a DataFrame from Polaris catalog via Spark.

    Uses spark.table() for catalog-based access, which properly routes through
    the configured Iceberg catalog (Polaris).

    Args:
        spark: Active SparkSession.
        catalog: Catalog name (must match the configured catalog name).
        namespace: Namespace path (e.g., "ag.isu_vertrieb.sales_schema").
        table: Table name (e.g., "CUSTOMERS").

    Returns:
        Spark DataFrame.
    """
    # Build the full table identifier
    # Format: catalog.namespace.table (namespace may have dots)
    table_identifier = f"{catalog}.{namespace}.{table}"

    logger.info(f"Loading DataFrame from Polaris: {table_identifier}")
    # Use spark.table() for catalog-based access (preferred for Iceberg catalogs)
    df = spark.table(table_identifier)

    logger.success(f"Loaded DataFrame from Polaris: {table_identifier} (count deferred)")
    return df


# TODO: implement this in a later sprint
def create_mock_catalog_table(
    polaris_path: dict,
    df: "pd.DataFrame",
) -> Path:
    """
    Create a mock catalog table (parquet file) for testing.

    Args:
        polaris_path: Dict with keys: catalog, namespace, table.
        df: Pandas DataFrame to save.

    Returns:
        Path to the created parquet file.
    """

    catalog = polaris_path.catalog
    namespace = polaris_path.namespace
    table = polaris_path.table

    # Convert namespace dots to path separators
    namespace_path = namespace.replace(".", "/")
    parquet_dir = settings.MOCK_CATALOG_DIR / catalog / namespace_path
    parquet_dir.mkdir(parents=True, exist_ok=True)

    parquet_path = parquet_dir / f"{table}.parquet"
    df.to_parquet(parquet_path, index=False)

    logger.info(f"Created mock catalog table: {parquet_path} ({len(df)} rows)")
    return parquet_path


# TODO: implement this in a later sprint
def register_dataframe_as_temp_view(
    df: DataFrame,
    view_name: str,
    spark: "SparkSession | None" = None,
) -> None:
    """
    Register a DataFrame as a temporary view for SQL queries.

    Used for multi-source rules (UnexpectedRowsExpectation).

    Args:
        df: DataFrame (Pandas or Spark).
        view_name: Name for the temporary view.
        spark: SparkSession (required for Pandas DataFrame in non-mock mode).
    """
    if settings.MOCK_SPARK:
        # In mock mode with Pandas, we can't create SQL views easily
        # Multi-source rules would need different handling
        logger.warning(f"Temp view '{view_name}' registration skipped in mock mode (Pandas)")
        return

    # Spark mode
    if hasattr(df, "createOrReplaceTempView"):
        # It's a Spark DataFrame
        df.createOrReplaceTempView(view_name)
        logger.info(f"Registered Spark DataFrame as temp view: {view_name}")
    else:
        # It's a Pandas DataFrame, convert to Spark
        if spark is None:
            raise ValueError("SparkSession required to convert Pandas DataFrame to Spark")
        spark_df = spark.createDataFrame(df)
        spark_df.createOrReplaceTempView(view_name)
        logger.info(f"Converted Pandas DataFrame and registered as temp view: {view_name}")


# -----------------------------------------------------------------------------
# Result Persistence Functions
# -----------------------------------------------------------------------------


def persist_result_rows(
    rows: list[dict],
    spark: "SparkSession | None" = None,
) -> int:
    """
    Persist result rows to Polaris DQ results table.

    Args:
        rows: List of row dicts to persist.
        spark: Optional Spark session. If None, creates one.

    Returns:
        Number of rows persisted.
    """
    if not rows:
        logger.warning("No rows to persist")
        return 0

    if settings.MOCK_CATALOG:
        # In mock mode, save to local JSON file
        return _persist_result_rows_to_mock(rows)
    else:
        # In production, write to Polaris/Snowflake
        return _persist_result_rows_to_polaris(rows, spark)


def _persist_result_rows_to_mock(rows: list[dict]) -> int:
    """
    Persist result rows to mock local storage (JSON file).

    Args:
        rows: List of row dicts to persist.

    Returns:
        Number of rows persisted.
    """
    import json

    mock_catalog_dir = settings.MOCK_CATALOG_DIR
    results_file = mock_catalog_dir / f"{settings.POLARIS_DQ_JUDGER_FULL_RESULTS_TABLE}.json"

    # Load existing rows if file exists
    existing_rows = []
    if results_file.exists():
        with open(results_file, "r", encoding=settings.FILE_ENCODING) as f:
            existing_rows = json.load(f)

    # Append new rows
    existing_rows.extend(rows)

    # Save back
    mock_catalog_dir.mkdir(parents=True, exist_ok=True)
    with open(results_file, "w", encoding=settings.FILE_ENCODING) as f:
        json.dump(existing_rows, f, indent=2, default=str)

    logger.info(f"Persisted {len(rows)} rows to mock catalog: {results_file}")
    return len(rows)


def _persist_result_rows_to_polaris(
    rows: list[dict],
    spark: "SparkSession | None" = None,
) -> int:
    """
    Persist result rows to Polaris/Snowflake table.

    Args:
        rows: List of row dicts to persist.
        spark: Optional Spark session. If None, creates one.

    Returns:
        Number of rows persisted.
    """
    if spark is None:
        spark = get_or_create_spark_session()

    # Create DataFrame from rows
    df = spark.createDataFrame(rows)

    # Write to Polaris table
    table_name = f"{settings.POLARIS_CATALOG_NAME}.{settings.POLARIS_DQ_NAMESPACE}.{settings.POLARIS_DQ_JUDGER_FULL_RESULTS_TABLE}"
    df.write.mode("append").saveAsTable(table_name)

    logger.success(f"Persisted {len(rows)} rows to Polaris: {table_name}")
    return len(rows)


def persist_summary(
    summary: "UseCaseSummaryResult",
    spark: "SparkSession | None" = None,
) -> int:
    """
    Persist summary row to Polaris DQ summary table.

    Args:
        summary: The UseCaseSummaryResult to persist.
        spark: Optional Spark session. If None, creates one.

    Returns:
        The summary_id (auto-generated) of the inserted row.
    """
    if settings.MOCK_CATALOG:
        return _persist_summary_to_mock(summary)
    else:
        return _persist_summary_to_polaris(summary, spark)


def _persist_summary_to_mock(summary: "UseCaseSummaryResult") -> int:
    """
    Persist summary to mock local storage (JSON file).

    Args:
        summary: The UseCaseSummaryResult to persist.

    Returns:
        The summary_id (simulated auto-increment).
    """
    import json
    from datetime import datetime, timezone

    mock_catalog_dir = settings.MOCK_CATALOG_DIR
    summary_file = mock_catalog_dir / f"{settings.POLARIS_DQ_JUDGER_SUMMARY_TABLE}.json"

    # Load existing summaries if file exists
    existing_summaries = []
    if summary_file.exists():
        with open(summary_file, "r", encoding=settings.FILE_ENCODING) as f:
            existing_summaries = json.load(f)

    # Generate summary_id (simulated auto-increment)
    summary_id = len(existing_summaries) + 1

    # Build summary row
    run_timestamp = datetime.now(timezone.utc).isoformat()
    summary_row = {
        "summary_id": summary_id,
        "domain": summary.domain,
        "use_case_name": summary.use_case_name,
        "total_tables": summary.total_tables,
        "passed_tables": summary.passed_tables,
        "failed_tables": summary.failed_tables,
        "data_docs_path": summary.data_docs_path,
        "run_timestamp": run_timestamp,
        "overall_success": summary.overall_success,
    }

    # Append and save
    existing_summaries.append(summary_row)
    mock_catalog_dir.mkdir(parents=True, exist_ok=True)
    with open(summary_file, "w", encoding=settings.FILE_ENCODING) as f:
        json.dump(existing_summaries, f, indent=2, default=str)

    logger.info(f"Persisted summary (id={summary_id}) to mock catalog: {summary_file}")
    return summary_id


def _persist_summary_to_polaris(
    summary: "UseCaseSummaryResult",
    spark: "SparkSession | None" = None,
) -> int:
    """
    Persist summary to Polaris/Snowflake table.

    Args:
        summary: The UseCaseSummaryResult to persist.
        spark: Optional Spark session. If None, creates one.

    Returns:
        The summary_id of the inserted row.
    """
    from datetime import datetime, timezone

    if spark is None:
        spark = get_or_create_spark_session()

    run_timestamp = datetime.now(timezone.utc).isoformat()
    summary_row = {
        "domain": summary.domain,
        "use_case_name": summary.use_case_name,
        "total_tables": summary.total_tables,
        "passed_tables": summary.passed_tables,
        "failed_tables": summary.failed_tables,
        "data_docs_path": summary.data_docs_path,
        "run_timestamp": run_timestamp,
        "overall_success": summary.overall_success,
    }

    # Create DataFrame and write
    df = spark.createDataFrame([summary_row])
    table_name = f"{settings.POLARIS_CATALOG_NAME}.{settings.POLARIS_DQ_NAMESPACE}.{settings.POLARIS_DQ_JUDGER_SUMMARY_TABLE}"
    df.write.mode("append").saveAsTable(table_name)

    # TODO: Get the actual auto-generated summary_id from the database
    # For now, return a placeholder
    logger.success(f"Persisted summary to Polaris: {table_name}")
    return 0  # Placeholder - actual ID comes from database
