"""
Script to create mock catalog parquet files for testing.

Creates sample data that matches the use_case_config.json expectations.
"""

import pandas as pd
import numpy as np
from pathlib import Path

# Get the base directory
BASE_DIR = Path(__file__).parent
MOCK_CATALOG_DIR = BASE_DIR / "data" / "mock_catalog"


def create_customers_table():
    """
    Create CUSTOMERS table matching the validation rules in use_case_config.json.
    
    Rules:
    - ExpectTableRowCountToBeBetween: min_value=1000, max_value=50000
    - ExpectColumnValuesToBeUnique: customer_id, mostly=1.0
    - ExpectColumnValuesToNotBeNull: customer_id, mostly=1.0
    - ExpectColumnValuesToBeInSet: status in ["Active", "Inactive", "Pending"], mostly=0.99
    """
    np.random.seed(42)
    n_rows = 1500  # Within 1000-50000 range
    
    # Generate customer_id - all unique and not null
    customer_ids = [f"CUST_{i:06d}" for i in range(1, n_rows + 1)]
    
    # Generate status - mostly valid values, with ~1% invalid to test mostly=0.99
    valid_statuses = ["Active", "Inactive", "Pending"]
    # Create weighted choices: 99% valid, 1% invalid (Unknown)
    all_statuses = valid_statuses + ["Unknown"]
    statuses = np.random.choice(all_statuses, size=n_rows, p=[0.33, 0.33, 0.33, 0.01])
    
    # Create DataFrame
    df = pd.DataFrame({
        "customer_id": customer_ids,
        "status": statuses,
        "name": [f"Customer {i}" for i in range(1, n_rows + 1)],
        "email": [f"customer{i}@example.com" for i in range(1, n_rows + 1)],
        "created_date": pd.date_range("2020-01-01", periods=n_rows, freq="h"),
    })
    
    # Create directory structure based on polaris_path
    # polaris_path: {"catalog": "enercity_catalog", "namespace": "encore_team.isu_vertrieb.sales_schema", "table": "CUSTOMERS"}
    output_dir = MOCK_CATALOG_DIR / "enercity_catalog" / "encore_team" / "isu_vertrieb" / "sales_schema"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_path = output_dir / "CUSTOMERS.parquet"
    df.to_parquet(output_path, index=False)
    
    print(f"Created {output_path} with {len(df)} rows")
    print(f"Columns: {list(df.columns)}")
    print("Status distribution:")
    for status, count in df["status"].value_counts().items():
        pct = count / len(df) * 100
        print(f"  {status}: {count} ({pct:.1f}%)")
    
    return df


def create_orders_table():
    """
    Create ORDERS table matching the validation rules in use_case_config.json.
    
    Rules (schema dimension - table level):
    - ExpectTableColumnsToMatchSet: columns should match set (PASS)
    - ExpectTableColumnsToMatchOrderedList: columns in specific order (FAIL - intentional)
    
    Rules (numeric dimension - column level):
    - ExpectColumnSumToBeBetween: amount sum between 10000 and 1000000 (PASS)
    - ExpectColumnValuesToBeBetween: quantity between 1 and 100 (PASS)
    
    NOTE: Column order is intentionally different from what ExpectTableColumnsToMatchOrderedList expects.
    Expected order: ["order_id", "customer_id", "amount", "quantity", "order_date", "status"]
    Actual order:   ["order_id", "customer_id", "order_date", "status", "amount", "quantity"]
    """
    np.random.seed(43)  # Different seed from customers
    n_rows = 500
    
    # Generate order_id - all unique
    order_ids = [f"ORD_{i:06d}" for i in range(1, n_rows + 1)]
    
    # Generate customer_id - reference to CUSTOMERS table (some valid, some orphan)
    # Most orders reference valid customers (CUST_000001 to CUST_001500)
    # A few orphan orders reference non-existent customers
    valid_customer_ids = [f"CUST_{np.random.randint(1, 1501):06d}" for _ in range(n_rows - 5)]
    orphan_customer_ids = [f"CUST_{999000 + i:06d}" for i in range(5)]  # These don't exist
    customer_ids = valid_customer_ids + orphan_customer_ids
    np.random.shuffle(customer_ids)
    
    # Generate amount - sum should be between 10000 and 1000000
    # With 500 rows, avg amount of 100-500 gives sum of 50000-250000
    amounts = np.random.uniform(50.0, 500.0, size=n_rows).round(2)
    
    # Generate quantity - all values between 1 and 100
    quantities = np.random.randint(1, 101, size=n_rows)
    
    # Generate order_date
    order_dates = pd.date_range("2024-01-01", periods=n_rows, freq="2h")
    
    # Generate status
    statuses = np.random.choice(["Pending", "Shipped", "Delivered", "Cancelled"], size=n_rows, p=[0.2, 0.3, 0.4, 0.1])
    
    # Create DataFrame with INTENTIONALLY WRONG column order for ExpectTableColumnsToMatchOrderedList test
    # Expected order: ["order_id", "customer_id", "amount", "quantity", "order_date", "status"]
    # Actual order:   ["order_id", "customer_id", "order_date", "status", "amount", "quantity"]
    df = pd.DataFrame({
        "order_id": order_ids,
        "customer_id": customer_ids,
        "order_date": order_dates,  # Wrong position
        "status": statuses,          # Wrong position
        "amount": amounts,           # Wrong position
        "quantity": quantities,      # Wrong position
    })
    
    # Create directory structure
    output_dir = MOCK_CATALOG_DIR / "enercity_catalog" / "encore_team" / "isu_vertrieb" / "sales_schema"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    output_path = output_dir / "ORDERS.parquet"
    df.to_parquet(output_path, index=False)
    
    print(f"Created {output_path} with {len(df)} rows")
    print(f"Columns (actual order): {list(df.columns)}")
    print(f"Amount sum: {df['amount'].sum():.2f} (should be between 10000-1000000)")
    print(f"Quantity range: {df['quantity'].min()}-{df['quantity'].max()} (should be 1-100)")
    print("Orphan orders (for multi-source test): 5 orders reference non-existent customers")
    
    return df


if __name__ == "__main__":
    print("Creating mock catalog data...")
    print()
    print("=" * 60)
    print("CUSTOMERS TABLE")
    print("=" * 60)
    create_customers_table()
    print()
    print("=" * 60)
    print("ORDERS TABLE")
    print("=" * 60)
    create_orders_table()
    print()
    print("Done!")
