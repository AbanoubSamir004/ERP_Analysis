"""
GX Config Builder Module

Builds GX artifacts (Context, Datasource, Asset, BatchDef, Suite, ValidationDef, Checkpoint)
from UI JSON configuration. This is the core of DAG Task 1.

Architecture:
- One GX Context per Use Case
- One Datasource per Use Case  
- One Checkpoint per Table (enables parallel execution in Task 2)
- Multiple ValidationDefs per Checkpoint (one per DQ dimension for cleaner Data Docs)
- Multiple Suites per Checkpoint (one per DQ dimension and inside its respective ValidationDef)

This module does NOT load data. It only builds the GX artifact structure.
Data loading and execution happens in Task 2 (gx_context_runner.py).

"""

import json
from pathlib import Path
from typing import TYPE_CHECKING, cast, Union

import great_expectations as gx
from great_expectations.core.validation_definition import ValidationDefinition
from great_expectations.checkpoint import Checkpoint, UpdateDataDocsAction

from blob_utils import upload_gx_context, download_gx_context
from custom_logger import logger
from env_config import settings
from gx_helpers import (
    get_asset_name,
    group_rules_by_dq_dimension,
    transform_ui_table_config_to_gx_format,
    get_data_docs_site_name
)
from pydantic_models import (
    UIUseCaseConfig,
    UseCaseMetacontent,
    BuilderOutput,
    CheckpointBuildMetacontent,
    TransformedGXRule
)

from general_helpers import remove_dir_or_file

# These are for IDE type checking only
if TYPE_CHECKING:
    from great_expectations.core.expectation_suite import ExpectationSuite
    from great_expectations.data_context import FileDataContext
    from great_expectations.datasource.fluent import SparkDatasource, PandasDatasource
    DataSource = Union[PandasDatasource, SparkDatasource]
    from great_expectations.datasource.fluent.spark_datasource import DataFrameAsset as SparkDataFrameAsset
    from great_expectations.datasource.fluent.pandas_datasource import DataFrameAsset as PandasDataFrameAsset, _PandasDataAsset
    from great_expectations.core.batch_definition import BatchDefinition

def load_use_case_config(config_path: str | Path) -> UIUseCaseConfig:
    """
    Load and parse a Use Case JSON configuration file.

    Args:
        config_path: Path to the JSON config file.

    Returns:
        Parsed UIUseCaseConfig Pydantic model.

    Raises:
        FileNotFoundError: If the config file does not exist.
        json.JSONDecodeError: If the config file is not valid JSON.
        pydantic.ValidationError: If the config doesn't match the schema.
    """
    config_path = Path(config_path)
    logger.info(f"Loading Use Case config from: {config_path}")
    
    if not config_path.exists():
        logger.error(f"Config file not found: {config_path}")
        raise FileNotFoundError(f"Config file not found: {config_path}")
    
    with open(config_path, "r", encoding=settings.FILE_ENCODING) as f:
        config_dict = json.load(f)
    
    # Parse into Pydantic model for validation and type safety
    config = UIUseCaseConfig.model_validate(config_dict)
    
    logger.info(
        f"Loaded Use Case: {config.use_case_name} (version: {config.version}, domain: {config.domain})"
    )
    
    return config


def build_gx_context(domain: str, use_case_name: str) -> Path:
    """
    Create or retrieve a GX FileDataContext at the `settings.CONTEXT_ROOT_DIR` directory.

    Args:
        domain: Domain name.
        use_case_name: Use Case name.

    Returns:
        The `context_root_dir` directory Path object.
    """
    context_root_dir = settings.CONTEXT_ROOT_DIR
    if settings.DELETE_LOCAL_GX_CONTEXT_BEFORE_BUILD:
        logger.debug("Deleting existing GX context directory (if any)")
        remove_dir_or_file(context_root_dir)
    logger.info("Building GX context...")
    context = gx.get_context(mode="file", context_root_dir=str(context_root_dir))
    logger.success(f"GX context initialized successfully. Location {context_root_dir}")

    logger.debug("Creating custom entry for `data_docs_sites` in `great_expectations.yml`")
    data_docs_dir = settings.DATA_DOCS_DIR
    logger.debug(f"directory to contain data docs' HTML file: {data_docs_dir}")
    context.add_data_docs_site(
        site_name=get_data_docs_site_name(domain, use_case_name),
        site_config={
            "class_name": "SiteBuilder",
            "site_index_builder": {"class_name": "DefaultSiteIndexBuilder"},
            "store_backend": {
                "class_name": "TupleFilesystemStoreBackend",
                "base_directory": str(data_docs_dir),
            },
        }
    )
    
    # SIDE NOTE: Could write `context.root_directory` as well instead of `context_root_dir`
    return context, context_root_dir



def build_datasource(
    context: "FileDataContext",
    datasource_name: str,
) -> "PandasDatasource | SparkDatasource":
    """
    Create or retrieve a datasource in the GX context.

    Uses MOCK_SPARK setting to determine datasource type:
    - MOCK_SPARK=True: Creates a Pandas datasource
    - MOCK_SPARK=False: Creates a Spark datasource

    Uses try/except pattern for idempotency.

    Args:
        context: The GX FileDataContext.
        datasource_name: Name for the datasource.

    Returns:
        The Datasource object (PandasDatasource or SparkDatasource).
    """
    datasource_type = "Pandas" if settings.MOCK_SPARK else "Spark"
    logger.info(f"Setting up {datasource_type} datasource: {datasource_name}")
    
    try:
        datasource = context.data_sources.get(datasource_name)
        logger.info(f"Retrieved existing datasource: {datasource_name}")
    except KeyError:
        if settings.MOCK_SPARK:
            datasource = context.data_sources.add_pandas(name=datasource_name)
            logger.info(f"Created new Pandas datasource: {datasource_name}")
        else:
            datasource = context.data_sources.add_spark(name=datasource_name)
            logger.info(f"Created new Spark datasource: {datasource_name}")
    
    return datasource


def build_data_asset(
    datasource: "PandasDatasource | SparkDatasource",
    asset_name: str,
) -> "PandasDataFrameAsset | SparkDataFrameAsset":
    """
    Create or retrieve a DataFrame asset on the datasource.

    Uses try/except pattern for idempotency.

    Args:
        datasource: The GX Datasource object (Pandas or Spark).
        asset_name: Name for the data asset (typically table name).

    Returns:
        The DataFrameAsset object (Aliased as "PandasDataFrameAsset" and "SparkDataFrameAsset" respectively).
    """
    logger.info(f"Setting up data asset: {asset_name}")
    
    try:
        asset = datasource.get_asset(asset_name)
        logger.info(f"Retrieved existing asset: {asset_name}")
    except LookupError:
        asset = datasource.add_dataframe_asset(name=asset_name)
        logger.info(f"Created new DataFrame asset: {asset_name}")
    
    return asset


def build_batch_definition(
    asset: "PandasDataFrameAsset | SparkDataFrameAsset",
    batch_def_name: str,
) -> "BatchDefinition":
    """
    Create or retrieve a batch definition for the asset.

    Args:
        asset: The GX DataAsset object.
        batch_def_name: Name for the batch definition.

    Returns:
        The BatchDefinition object.
    """
    logger.info(f"Setting up batch definition: {batch_def_name}")

    # NOTE: This line is written purely for IDE purposes to help us developers in debugging, 
    #       as `add_batch_definition_whole_dataframe` won't appear with `PandasDataFrameAsset` 
    #       even though it inherits from `_PandasDataAsset`,
    #       probably because the latter is private (hence the `_` prefix), and I think (not sure)
    #       that IDEs don't pick up on private classes within 3rd party packages.
    asset = cast("_PandasDataAsset | PandasDataFrameAsset | SparkDataFrameAsset", asset)
    
    try:
        batch_def = asset.get_batch_definition(batch_def_name)
        logger.info(f"Retrieved existing batch definition: {batch_def_name}")
    except KeyError:
        batch_def = asset.add_batch_definition_whole_dataframe(name=batch_def_name)
        logger.info(f"Created new batch definition: {batch_def_name}")
    
    return batch_def


def build_expectation_suite(
    context: "FileDataContext",
    suite_name: str,
    gx_rules: list[TransformedGXRule],
) -> "ExpectationSuite":
    """
    Create an ExpectationSuite from transformed GX rules and register it in context.

    Args:
        context: The GX FileDataContext.
        suite_name: Name for the expectation suite.
        gx_rules: List of transformed rule dicts (from transform_ui_table_config_to_gx_format).

    Returns:
        The populated ExpectationSuite.
    """
    logger.info(f"Building expectation suite: {suite_name} with {len(gx_rules)} rules")
    
    # Populate the suite with expectations
    # TODO Later: See how this can be refactored (while retaining comments) so that it uses 
    #             gx_helpers.populate_expectation_suite() instead
    suite = gx.ExpectationSuite(name=suite_name)
    for rule in gx_rules:
        expectation_type = rule.expectation_type
        params = rule.params
        # Technical NOTE: Use exclude_none=True to skip fields with None values 
        # (e.g., column=None for table-level expectations)
        # Otherwise, we'll get an "extra fields not permitted" error, because under the hood, GX uses 
        #   Pydantic v1 with strict validation (extra="forbid"), 
        #   and since table-level expectations don't include a "column" field,
        #   therefore Pydantic v1 rejects the column field for table-level expectations 
        #   like ExpectTableRowCountToBeBetween
        params_dict = params.model_dump(exclude_none=True)
        
        try:
            # Dynamically get the expectation class from gx.expectations
            expectation_class = getattr(gx.expectations, expectation_type)
            # Convert Pydantic model to dict for unpacking
            expectation = expectation_class(**params_dict, catch_exceptions=settings.CATCH_EXPECTATION_EXCEPTION)
            suite.add_expectation(expectation)
            
            logger.info(f"Added expectation: {expectation_type}")
            
        except AttributeError:
            logger.exception(f"Expectation type '{expectation_type}' not found in gx.expectations. Skipping.")
        except TypeError as e:
            logger.error(f"TypeError creating expectation '{expectation_type}' with params {params_dict}")
            logger.exception(f"The caught error: {e}")
        except Exception as e:
            logger.exception(f"Unexpected error adding expectation '{expectation_type}': {e}")

    
    # Add to context, or update if a suite with the same name exists
    suite = context.suites.add_or_update(suite)
    logger.info(f"Registered suite in context: {suite_name}")
    
    return suite


def build_validation_definition(
    context: "FileDataContext",
    validation_def_name: str,
    batch_definition: "BatchDefinition",
    suite: "ExpectationSuite",
) -> "ValidationDefinition":
    """
    Create a ValidationDefinition linking a batch definition to a suite.

    Args:
        context: The GX FileDataContext.
        validation_def_name: Name for the validation definition.
        batch_definition: The BatchDefinition object.
        suite: The ExpectationSuite object.

    Returns:
        The ValidationDefinition object.
    """
    logger.info(f"Building validation definition: {validation_def_name}")
    
    validation_def = ValidationDefinition(
        name=validation_def_name,
        data=batch_definition,
        suite=suite,
    )
    
    # Register in context (add or update)
    validation_def = context.validation_definitions.add_or_update(validation_def)
    logger.info(f"Registered validation definition in context: {validation_def_name}")
    
    return validation_def


def build_checkpoint(
    context: "FileDataContext",
    checkpoint_name: str,
    validation_definitions: list["ValidationDefinition"],
    domain: str,
    use_case_name: str
) -> "Checkpoint":
    """
    Create a Checkpoint containing all validation definitions for the Use Case.

    Args:
        context: The GX FileDataContext.
        checkpoint_name: Name for the checkpoint (typically {domain}_{use_case_name}).
        validation_definitions: List of ValidationDefinition objects.
        domain: Domain name (used for data docs site naming).
        use_case_name: Use Case name (used for data docs site naming).

    Returns:
        The Checkpoint object.
    """
    logger.info(f"Building checkpoint: {checkpoint_name}")


    
    # Build actions list - always include update_data_docs
    actions = [
        UpdateDataDocsAction(
            name="update_data_docs", 
            site_names=[get_data_docs_site_name(domain, use_case_name)]
        ),
    ]
    
    checkpoint = Checkpoint(
        name=checkpoint_name,
        validation_definitions=validation_definitions,
        actions=actions,
        result_format={"result_format": "COMPLETE"},
    )
    
    # Register in context (add or update)
    checkpoint = context.checkpoints.add_or_update(checkpoint)
    logger.info(f"Registered checkpoint in context: {checkpoint_name}")
    
    return checkpoint


def build_gx_artifacts_from_config(
    config: UIUseCaseConfig,
) -> BuilderOutput:
    """
    Main entry point: Build all GX artifacts from a Use Case configuration.

    This function orchestrates the entire artifact building process:
    1. Creates/retrieves the GX context
    2. Creates a Spark datasource
    3. For each table:
        a. Creates Asset, BatchDef
        b. Groups rules by DQ dimension
        c. For each dimension: creates Suite, ValidationDef
        d. Creates one Checkpoint per table (containing all VDs for that table)

    Architecture:
    - One Checkpoint per Table (enables parallel execution in Task 2)
    - Multiple VDs per Checkpoint (one per DQ dimension for cleaner Data Docs)

    Args:
        config: Parsed UIUseCaseConfig Pydantic model.

    Returns:
        A BuilderOutput containing:
        - context: The FileDataContext
        - checkpoints: List of Checkpoint objects (one per table)
        - checkpoints_build_metacontent: List of CheckpointBuildMetacontent for Task 2
        - context_root_dir: Path to the context folder
    """
    use_case_name = config.use_case_name
    domain = config.domain.lower()
    tables = config.tables
    
    # Build use case metacontent for passing to transform functions
    use_case_metacontent = UseCaseMetacontent(
        use_case_name=use_case_name,
        domain=domain,
        version=config.version,
    )
    
    logger.info(
        f"Building GX artifacts for Use Case: {use_case_name} (domain: {domain}, tables: {len(tables)})"
    )
    
    # 0. Optionally download existing GX context from blob (to preserve artifact IDs across runs)
    if settings.DOWNLOAD_BLOB_GX_CONTEXT_BEFORE_BUILD:
        try:
            logger.info("Downloading existing GX context from blob storage before build...")
            download_gx_context(domain, use_case_name)
            logger.success("Downloaded GX context from blob storage")
        except FileNotFoundError:
            logger.warning("No existing GX context found in blob storage, starting fresh")
    
    # 1. Build gx context
    context, context_root_dir = build_gx_context(domain, use_case_name)
    
    # 2. Build datasource (one per Use Case)
    sep = settings.NAME_SEPARATOR
    datasource_name = f"{domain}{sep}{use_case_name}{sep}datasource"
    datasource = build_datasource(context, datasource_name)
    
    # 3. For each table: build Checkpoint with VDs grouped by DQ dimension
    checkpoints = []
    checkpoints_build_metacontent = []
    
    for table_config in tables:
        table_id = table_config.table_id
        
        # Build data asset
        asset_name = get_asset_name(table_config)
        logger.info(f"Processing table {table_id=}: {asset_name=}")
        asset = build_data_asset(datasource, asset_name)
        
        # Build batch definition (one per table, used by all VDs for this table)
        batch_def_name = f"{asset_name}{sep}whole_batch"
        batch_def = build_batch_definition(asset, batch_def_name)
        
        # Transform UI rules to GX format (includes metacontent injection)
        all_rules = transform_ui_table_config_to_gx_format(table_config, use_case_metacontent)
        
        # Group rules by DQ dimension
        rules_by_dimension = group_rules_by_dq_dimension(all_rules)
        
        # Build one Suite + VD per DQ dimension
        validation_definitions = []
        for dq_dimension, dimension_rules in rules_by_dimension.items():
            # Build expectation suite for this dimension
            suite_name = f"{asset_name}{sep}{dq_dimension}{sep}suite"
            suite = build_expectation_suite(context, suite_name, dimension_rules)

            # Build validation definition for this dimension
            vd_name = f"{asset_name}{sep}{dq_dimension}{sep}vd"
            validation_def = build_validation_definition(context, vd_name, batch_def, suite)
            validation_definitions.append(validation_def)

        # Build checkpoint for this table (contains all VDs for all dimensions)
        checkpoint_name = f"{asset_name}{sep}checkpoint"
        checkpoint = build_checkpoint(context, checkpoint_name, validation_definitions, domain, use_case_name)
        checkpoints.append(checkpoint)
        
        # Store metacontent for Task 2
        checkpoints_build_metacontent.append(CheckpointBuildMetacontent(
            checkpoint_name=checkpoint_name,
            table_id=table_id,
            table_name=asset_name,
            polaris_path=table_config.polaris_path,
            batch_def_name=batch_def_name,
            dq_dimensions=list(rules_by_dimension.keys()),
            validation_def_count=len(validation_definitions),
        ))
    
    logger.success(
        f"Successfully built all GX artifacts for Use Case: {use_case_name} "
        f"({len(checkpoints)} checkpoints, one per table)"
    )
    
    return BuilderOutput(
        context=context,
        checkpoints=checkpoints,
        checkpoints_build_metacontent=checkpoints_build_metacontent,
        context_root_dir=str(context_root_dir),
    )


# -----------------------------------------------------------------------------
# CLI Entry Point (for local testing)
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    
    # Example usage
    if len(sys.argv) < 2:
        logger.error("Usage: python gx_config_builder.py <config_path>")
        logger.info("Example: python gx_config_builder.py ./sample_config.json")
        sys.exit(1)
    
    config_path = sys.argv[1]
    
    try:
        # Load config
        config = load_use_case_config(config_path)
        domain = config.domain
        use_case_name = config.use_case_name
        
        # Build artifacts
        result = build_gx_artifacts_from_config(config)
        
        logger.info("GX artifacts built successfully!")
        logger.info(f"Context path: {result.context_root_dir}")
        logger.info(f"Checkpoints: {[cp.name for cp in result.checkpoints]}")
        logger.debug(f"Checkpoint metacontent: {result.checkpoints_build_metacontent}")
        # logger.info(f"Checkpoint metacontent: {json.dumps([m.model_dump() for m in result.checkpoints_build_metacontent], indent=2)}")

        # Save checkpoint metacontent for Task 2
        # TODO: add MOCK_AIRFLOW_XCOM on/off logics in a later sprint
        if settings.MOCK_AIRFLOW_XCOM:
            metadata_path = settings.MOCK_AIRFLOW_XCOM_DIR / "checkpoints_build_metacontent.json"
            with open(metadata_path, "w", encoding=settings.FILE_ENCODING) as f:
                # Serialize Pydantic models to dicts for JSON
                metadata_dicts = [m.model_dump() for m in result.checkpoints_build_metacontent]
                json.dump(metadata_dicts, f, indent=2)
            logger.success(f"Saved checkpoint metacontent to: {metadata_path}")
        else:
            raise ValueError("MOCK_AIRFLOW_XCOM should be True. Otherwise, implement real XCom logic.")
                
        # Upload GX context to blob storage (simulates production upload)
        # In mock mode, this copies to data/mock_adls/{domain}/{use_case_name}/gx/
        blob_path = upload_gx_context(domain, use_case_name, result.context_root_dir)
        logger.success(f"Uploaded GX context to blob: {blob_path}")
        
    except Exception as e:
        logger.exception(f"Failed to build GX artifacts: {e}")
        sys.exit(1)
