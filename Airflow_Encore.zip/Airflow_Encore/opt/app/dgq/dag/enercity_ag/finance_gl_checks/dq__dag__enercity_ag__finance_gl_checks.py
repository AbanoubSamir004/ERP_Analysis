from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.pod import KubernetesPodOperator
from datetime import datetime
from airflow.models import Variable

# Define the credentials and environment variables for Airflow tasks
dag_schedule_var = Variable.get("my_variable_name", default=None)

# Get a regular string variable with a default value of None if not found
airflow_env = {
    "AZURE_STORAGE_ACCOUNT": "{{ var.value.azure_account }}",
    "AZURE_SAS_TOKEN": "{{ var.value.azure_sas_token }}",
    "AZURE_CONTAINER": "{{ var.value.blob_container }}",
    "POSTGRES_URL": "{{ var.value.postgres_uri }}"
}

with DAG(
    dag_id="dq__dag__enercity_ag__finance_gl_checks",
    start_date=datetime(2024, 1, 1),
    schedule=dag_schedule_var,
    catchup=False
) as dag:

    # 1. Builder: JSON -> YAML
    # We use .partial for settings that are the same for all dynamic tasks
    task_builder = KubernetesPodOperator.partial(
        task_id="gx_builder",
        image="yourregistry.azurecr.io/gx-spark-app:latest",
        namespace="airflow",
        env_vars=airflow_env, # Injects your Airflow Vars
        do_xcom_push=True,
        cmds=["python", "/opt/app/dgq/gx_context_builder.py"]
    ).expand(
        # This creates a task for every config file
        arguments=[["--config", f] for f in ["use_case_config.json"]]
    )

    # 2. Runner: YAML -> Spark Results
    task_runner = KubernetesPodOperator.partial(
        task_id="gx_runner",
        image="yourregistry.azurecr.io/gx-spark-app:latest",
        namespace="airflow",
        env_vars=airflow_env,
        do_xcom_push=True,
        cmds=["python", "/opt/app/dgq/gx_context_runner.py"]
    ).expand(
        # Automatically maps the output path from builder to runner
        arguments=[["--yaml_path", path] for path in task_builder.output]
    )

    # 3. Post-Process: Results -> Postgres
    task_postprocess = KubernetesPodOperator.partial(
        task_id="gx_postprocess",
        image="yourregistry.azurecr.io/gx-spark-app:latest",
        namespace="airflow",
        env_vars=airflow_env,
        cmds=["python", "/opt/app/dgq/gx_postprocessor.py"]
    ).expand(
        arguments=[["--result_path", path] for path in task_runner.output]
    )

    task_builder >> task_runner >> task_postprocess